/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.onion.onioboard.latin.settings;

import android.os.Bundle;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.preference.Preference;
import android.preference.ListPreference;
import android.preference.SwitchPreference;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;

import com.onion.onioboard.R;
import com.onion.onioboard.latin.utils.ApplicationUtils;

public final class SettingsFragment extends InputMethodSettingsFragment {
    @Override
    public void onCreate(final Bundle icicle) {
        super.onCreate(icicle);
        setHasOptionsMenu(true);
        setInputMethodSettingsCategoryTitle(R.string.language_selection_title);
        setSubtypeEnablerTitle(R.string.select_language);
        addPreferencesFromResource(R.xml.prefs);

        final SwitchPreference hidingEnabledPreference =
                (SwitchPreference) findPreference("pref_hiding_enabled");
        final ListPreference hidingModePreference =
                (ListPreference) findPreference("pref_hiding_mode");
        if (hidingEnabledPreference != null && hidingModePreference != null) {
            final ComponentName launcherComponent = new ComponentName(
                    getActivity(),
                    "com.onion.onioboard.latin.settings.Launcher");
            final PackageManager packageManager = getActivity().getPackageManager();
            final SharedPreferences preferences =
                    PreferenceManager.getDefaultSharedPreferences(getActivity());

            String storedMode = preferences.getString("pref_hiding_mode", null);
            if (storedMode == null) {
                storedMode = preferences.getBoolean("pref_hide_from_launcher", false)
                        ? "hide" : "spoof";
            } else if ("redirect".equals(storedMode) || "normal".equals(storedMode)) {
                storedMode = "spoof";
            }
            hidingModePreference.setValue(storedMode);
            preferences.edit().putString("pref_hiding_mode", storedMode).apply();

            boolean hidingEnabled = preferences.getBoolean("pref_hiding_enabled",
                    preferences.contains("pref_hide_from_launcher")
                            && preferences.getBoolean("pref_hide_from_launcher", false));
            hidingEnabledPreference.setChecked(hidingEnabled);
            applyLauncherMode(packageManager, launcherComponent,
                    hidingEnabled, storedMode);
            updateHidingSummary(hidingEnabledPreference, hidingEnabled);
            updateHidingModeSummary(hidingModePreference, storedMode);

            hidingEnabledPreference.setOnPreferenceChangeListener(
                    new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    boolean enabled = (Boolean) newValue;
                    String mode = hidingModePreference.getValue() == null
                            ? "spoof" : hidingModePreference.getValue();
                    applyLauncherMode(packageManager, launcherComponent, enabled, mode);
                    preferences.edit().putBoolean("pref_hiding_enabled", enabled).apply();
                    updateHidingSummary(hidingEnabledPreference, enabled);
                    return true;
                }
            });

            hidingModePreference.setOnPreferenceChangeListener(
                    new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    String mode = (String) newValue;
                    boolean enabled = hidingEnabledPreference.isChecked();
                    applyLauncherMode(packageManager, launcherComponent, enabled, mode);
                    preferences.edit().putString("pref_hiding_mode", mode).apply();
                    updateHidingModeSummary(hidingModePreference, mode);
                    return true;
                }
            });
        }

        final PreferenceScreen preferenceScreen = getPreferenceScreen();
        preferenceScreen.setTitle(
                ApplicationUtils.getActivityTitleResId(getActivity(), SettingsActivity.class));
    }

    private static void applyLauncherMode(PackageManager packageManager,
            ComponentName launcherComponent, boolean hidingEnabled, String mode) {
        boolean hide = hidingEnabled && "hide".equals(mode);
        packageManager.setComponentEnabledSetting(
                launcherComponent,
                hide ? PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                     : PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                0);
    }

    private static void updateHidingSummary(
            SwitchPreference preference, boolean enabled) {
        preference.setSummary(enabled
                ? "Enabled • Choose how OnioBoard appears in the launcher below"
                : "Disabled • App opens normally");
    }

    private static void updateHidingModeSummary(
            ListPreference preference, String mode) {
        if ("hide".equals(mode)) {
            preference.setSummary("Hide it from the launcher itself");
        } else {
            preference.setSummary("Spoof as Gboard • Opens Gboard when tapped");
        }
    }

}
