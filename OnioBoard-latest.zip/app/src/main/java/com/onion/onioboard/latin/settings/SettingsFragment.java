/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.onion.onioboard.latin.settings;

import android.os.Bundle;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.preference.Preference;
import android.preference.ListPreference;
import android.preference.SwitchPreference;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;

import com.onion.onioboard.R;
import com.onion.onioboard.latin.utils.ApplicationUtils;

public final class SettingsFragment extends InputMethodSettingsFragment {
    @Override
    public void onCreate(final Bundle icicle) {
        super.onCreate(icicle);
        setHasOptionsMenu(true);
        setInputMethodSettingsCategoryTitle(R.string.language_selection_title);
        setSubtypeEnablerTitle(R.string.select_language);
        addPreferencesFromResource(R.xml.prefs);

        final SwitchPreference hidingEnabledPreference =
                (SwitchPreference) findPreference("pref_hiding_enabled");
        final Preference hidingNote = findPreference("pref_hiding_mode_note");
        if (hidingEnabledPreference != null) {
            final ComponentName launcherComponent = new ComponentName(
                    getActivity(), "com.onion.onioboard.latin.settings.Launcher");
            final PackageManager packageManager = getActivity().getPackageManager();
            final SharedPreferences preferences =
                    PreferenceManager.getDefaultSharedPreferences(getActivity());
            final boolean hidingEnabled =
                    preferences.getBoolean("pref_hiding_enabled", false);
            hidingEnabledPreference.setChecked(hidingEnabled);
            applyLauncherHiddenState(packageManager, launcherComponent, hidingEnabled);
            updateHidingSummary(hidingEnabledPreference, hidingEnabled);
            if (hidingNote != null) hidingNote.setEnabled(hidingEnabled);

            hidingEnabledPreference.setOnPreferenceChangeListener(
                    new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    final boolean hide = (Boolean) newValue;
                    applyLauncherHiddenState(packageManager, launcherComponent, hide);
                    updateHidingSummary(hidingEnabledPreference, hide);
                    if (hidingNote != null) hidingNote.setEnabled(hide);
                    return true;
                }
            });
        }

        final PreferenceScreen preferenceScreen = getPreferenceScreen();
        preferenceScreen.setTitle(
                ApplicationUtils.getActivityTitleResId(getActivity(), SettingsActivity.class));
    }

    private static void applyLauncherHiddenState(PackageManager packageManager,
            ComponentName launcherComponent, boolean hide) {
        packageManager.setComponentEnabledSetting(
                launcherComponent,
                hide ? PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                     : PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP);
    }

    private static void updateHidingSummary(
            SwitchPreference preference, boolean enabled) {
        preference.setSummary(enabled
                ? "Enabled • OnioBoard is hidden from the launcher"
                : "Disabled • App opens normally");
    }

}
