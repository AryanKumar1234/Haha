/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.onion.onioboard.latin.settings;

import android.os.Bundle;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.preference.Preference;
import android.preference.ListPreference;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;

import com.onion.onioboard.R;
import com.onion.onioboard.latin.utils.ApplicationUtils;

public final class SettingsFragment extends InputMethodSettingsFragment {
    @Override
    public void onCreate(final Bundle icicle) {
        super.onCreate(icicle);
        setHasOptionsMenu(true);
        setInputMethodSettingsCategoryTitle(R.string.language_selection_title);
        setSubtypeEnablerTitle(R.string.select_language);
        addPreferencesFromResource(R.xml.prefs);

        final ListPreference hidingModePreference =
                (ListPreference) findPreference("pref_hiding_mode");
        if (hidingModePreference != null) {
            final ComponentName launcherComponent = new ComponentName(
                    getActivity(),
                    "com.onion.onioboard.latin.settings.Launcher");
            final PackageManager packageManager = getActivity().getPackageManager();
            final SharedPreferences preferences =
                    PreferenceManager.getDefaultSharedPreferences(getActivity());

            // Migrate earlier switches and the former redirect mode.
            String storedMode = preferences.getString("pref_hiding_mode", null);
            if (storedMode == null) {
                storedMode = preferences.getBoolean("pref_hide_from_launcher", false)
                        ? "hide" : "spoof";
            } else if ("redirect".equals(storedMode) || "normal".equals(storedMode)) {
                // The visible mode now opens OnioBoard itself; it never launches Gboard.
                storedMode = "spoof";
            }
            hidingModePreference.setValue(storedMode);
            preferences.edit().putString("pref_hiding_mode", storedMode).apply();

            final String currentMode = hidingModePreference.getValue() == null
                    ? "spoof" : hidingModePreference.getValue();
            final boolean isHidden = "hide".equals(currentMode);
            packageManager.setComponentEnabledSetting(
                    launcherComponent,
                    isHidden ? PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                             : PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    0);
            updateHidingModeSummary(hidingModePreference, currentMode);

            hidingModePreference.setOnPreferenceChangeListener(
                    new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    final String selectedMode = (String) newValue;
                    final boolean hide = "hide".equals(selectedMode);
                    packageManager.setComponentEnabledSetting(
                            launcherComponent,
                            hide ? PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                                 : PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                            0);
                    updateHidingModeSummary(hidingModePreference, selectedMode);
                    return true;
                }
            });
        }

        final PreferenceScreen preferenceScreen = getPreferenceScreen();
        preferenceScreen.setTitle(
                ApplicationUtils.getActivityTitleResId(getActivity(), SettingsActivity.class));
    }

    private static void updateHidingModeSummary(
            ListPreference preference, String mode) {
        if ("spoof".equals(mode)) {
            preference.setSummary("Enabled • App appears as Gboard in the launcher");
        } else if ("hide".equals(mode)) {
            preference.setSummary("Enabled • OnioBoard is hidden from your app drawer");
        } else {
            preference.setSummary("Enabled • App appears as Gboard in the launcher");
        }
    }

}
