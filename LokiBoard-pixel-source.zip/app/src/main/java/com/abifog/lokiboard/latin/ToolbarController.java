package com.abifog.lokiboard.latin;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.TextView;

import com.abifog.lokiboard.R;
import com.abifog.lokiboard.latin.common.Constants;

/**
 * Gboard-style toolbar above the keyboard: emoji, clipboard paste, language switch,
 * settings and voice input.
 */
final class ToolbarController {
    private static final String[] EMOJIS = {
            "\uD83D\uDE00", "\uD83D\uDE03", "\uD83D\uDE04", "\uD83D\uDE01", "\uD83D\uDE06", "\uD83D\uDE05", "\uD83D\uDE02", "\uD83E\uDD23",
            "\uD83D\uDE0A", "\uD83D\uDE07", "\uD83D\uDE42", "\uD83D\uDE43", "\uD83D\uDE09", "\uD83D\uDE0C", "\uD83D\uDE0D", "\uD83E\uDD70",
            "\uD83D\uDE18", "\uD83D\uDE17", "\uD83D\uDE19", "\uD83D\uDE1A", "\uD83D\uDE0B", "\uD83D\uDE1B", "\uD83D\uDE1D", "\uD83D\uDE1C",
            "\uD83E\uDD2A", "\uD83E\uDD28", "\uD83E\uDDD0", "\uD83E\uDD13", "\uD83D\uDE0E", "\uD83E\uDD73", "\uD83D\uDE0F", "\uD83D\uDE12",
            "\uD83D\uDE1E", "\uD83D\uDE14", "\uD83D\uDE1F", "\uD83D\uDE15", "\uD83D\uDE41", "\u2639\uFE0F", "\uD83D\uDE23", "\uD83D\uDE16",
            "\uD83D\uDE2B", "\uD83D\uDE29", "\uD83E\uDD7A", "\uD83D\uDE22", "\uD83D\uDE2D", "\uD83D\uDE24", "\uD83D\uDE20", "\uD83D\uDE21",
            "\uD83E\uDD2C", "\uD83E\uDD2F", "\uD83D\uDE33", "\uD83E\uDD75", "\uD83E\uDD76", "\uD83D\uDE31", "\uD83D\uDE28", "\uD83D\uDE30",
            "\uD83D\uDE25", "\uD83D\uDE13", "\uD83E\uDD17", "\uD83E\uDD14", "\uD83E\uDD2D", "\uD83E\uDD2B", "\uD83E\uDD25", "\uD83D\uDE36",
            "\uD83D\uDE10", "\uD83D\uDE11", "\uD83D\uDE2C", "\uD83D\uDE44", "\uD83D\uDE2F", "\uD83D\uDE26", "\uD83D\uDE27", "\uD83D\uDE2E",
            "\uD83D\uDE32", "\uD83E\uDD71", "\uD83D\uDE34", "\uD83E\uDD24", "\uD83D\uDE2A", "\uD83D\uDE35", "\uD83E\uDD10", "\uD83E\uDD74",
            "\uD83E\uDD22", "\uD83E\uDD2E", "\uD83E\uDD27", "\uD83D\uDE37", "\uD83E\uDD12", "\uD83E\uDD15", "\uD83E\uDD11", "\uD83E\uDD20",
            "\uD83D\uDE08", "\uD83D\uDC7F", "\uD83D\uDC79", "\uD83D\uDC7A", "\uD83E\uDD21", "\uD83D\uDCA9", "\uD83D\uDC7B", "\uD83D\uDC80",
            "\u2620\uFE0F", "\uD83D\uDC7D", "\uD83E\uDD16", "\uD83C\uDF83", "\uD83D\uDC4B", "\uD83E\uDD1A", "\uD83D\uDD90\uFE0F", "\u270B",
            "\uD83D\uDD96", "\uD83D\uDC4C", "\uD83E\uDD0F", "\u270C\uFE0F", "\uD83E\uDD1E", "\uD83E\uDD1F", "\uD83E\uDD18", "\uD83E\uDD19",
            "\uD83D\uDC48", "\uD83D\uDC49", "\uD83D\uDC46", "\uD83D\uDC47", "\u261D\uFE0F", "\uD83D\uDC4D", "\uD83D\uDC4E", "\u270A",
            "\uD83D\uDC4A", "\uD83E\uDD1B", "\uD83E\uDD1C", "\uD83D\uDC4F", "\uD83D\uDE4C", "\uD83D\uDC50", "\uD83E\uDD32", "\uD83E\uDD1D",
            "\uD83D\uDE4F", "\u270D\uFE0F", "\uD83D\uDCAA", "\uD83E\uDDBE", "\uD83D\uDC40", "\uD83D\uDC41\uFE0F", "\uD83D\uDC45", "\uD83D\uDC44",
            "\u2764\uFE0F", "\uD83E\uDDE1", "\uD83D\uDC9B", "\uD83D\uDC9A", "\uD83D\uDC99", "\uD83D\uDC9C", "\uD83D\uDDA4", "\uD83E\uDD0D",
            "\uD83E\uDD0E", "\uD83D\uDC94", "\u2763\uFE0F", "\uD83D\uDC95", "\uD83D\uDC9E", "\uD83D\uDC93", "\uD83D\uDC97", "\uD83D\uDC96",
            "\uD83D\uDC98", "\uD83D\uDC9D", "\uD83D\uDCAF", "\uD83D\uDCA2", "\uD83D\uDCA5", "\uD83D\uDCAB", "\uD83D\uDCA6", "\uD83D\uDCA8",
            "\uD83D\uDCA4", "\u2728", "\uD83D\uDD25", "\u2B50", "\uD83C\uDF1F", "\u26A1", "\uD83C\uDF08", "\u2600\uFE0F",
            "\u2601\uFE0F", "\u2744\uFE0F", "\u2614", "\uD83C\uDF89", "\uD83C\uDF8A", "\uD83C\uDF88", "\uD83C\uDF81", "\uD83C\uDFC6",
            "\uD83E\uDD47", "\u26BD", "\uD83C\uDFC0", "\uD83C\uDFCF", "\uD83C\uDFAE", "\uD83C\uDFB5", "\uD83C\uDFB6", "\uD83C\uDFA4",
            "\uD83C\uDFA7", "\uD83D\uDC36", "\uD83D\uDC31", "\uD83D\uDC2D", "\uD83D\uDC39", "\uD83D\uDC30", "\uD83E\uDD8A", "\uD83D\uDC3B",
            "\uD83D\uDC3C", "\uD83D\uDC28", "\uD83D\uDC2F", "\uD83E\uDD81", "\uD83D\uDC2E", "\uD83D\uDC37", "\uD83D\uDC38", "\uD83D\uDC35",
            "\uD83D\uDE48", "\uD83D\uDE49", "\uD83D\uDE4A", "\uD83D\uDC14", "\uD83D\uDC27", "\uD83D\uDC26", "\uD83E\uDD86", "\uD83E\uDD85",
            "\uD83E\uDD89", "\uD83D\uDC3A", "\uD83D\uDC34", "\uD83E\uDD84", "\uD83D\uDC1D", "\uD83E\uDD8B", "\uD83D\uDC22", "\uD83D\uDC0D",
            "\uD83D\uDC19", "\uD83D\uDC2C", "\uD83D\uDC33", "\uD83C\uDF39", "\uD83C\uDF3B", "\uD83C\uDF38", "\uD83C\uDF34", "\uD83C\uDF40",
            "\uD83C\uDF4E", "\uD83C\uDF4A", "\uD83C\uDF4B", "\uD83C\uDF4C", "\uD83C\uDF49", "\uD83C\uDF47", "\uD83C\uDF53", "\uD83C\uDF52",
            "\uD83C\uDF51", "\uD83E\uDD6D", "\uD83C\uDF4D", "\uD83E\uDD65", "\uD83E\uDD51", "\uD83C\uDF45", "\uD83C\uDF3D", "\uD83E\uDD55",
            "\uD83C\uDF54", "\uD83C\uDF5F", "\uD83C\uDF55", "\uD83C\uDF2D", "\uD83C\uDF2E", "\uD83C\uDF7F", "\uD83C\uDF69", "\uD83C\uDF6A",
            "\uD83C\uDF82", "\uD83C\uDF70", "\uD83C\uDF6B", "\uD83C\uDF6C", "\u2615", "\uD83C\uDF75", "\uD83C\uDF7A", "\uD83C\uDF7B",
            "\uD83E\uDD42", "\uD83C\uDF77", "\uD83D\uDE97", "\uD83D\uDE95", "\uD83D\uDE8C", "\uD83C\uDFCD\uFE0F", "\uD83D\uDEB2", "\u2708\uFE0F",
            "\uD83D\uDE80", "\uD83D\uDE81", "\u26F5", "\uD83D\uDEA2", "\uD83C\uDFE0", "\uD83C\uDFE2", "\uD83C\uDFE5", "\uD83C\uDFEB",
            "\u26EA\uFE0F", "\uD83D\uDD4C", "\uD83D\uDD4D", "\uD83C\uDF0D", "\uD83C\uDF19", "\uD83D\uDCF1", "\uD83D\uDCBB", "\u231A",
            "\uD83D\uDCF7", "\uD83D\uDCA1", "\uD83D\uDD11", "\uD83D\uDD12", "\uD83D\uDCDE", "\u2709\uFE0F", "\uD83D\uDCCC", "\u2702\uFE0F",
            "\u270F\uFE0F", "\uD83D\uDCDA", "\uD83D\uDCB0", "\uD83D\uDC8E", "\u2705", "\u274C", "\u2753", "\u2757",
            "\u26A0\uFE0F", "\u2795", "\u2796", "\u27A1\uFE0F", "\u2B05\uFE0F", "\uD83D\uDD14", "\uD83C\uDDEE\uD83C\uDDF3",
    };

    private final LatinIME mIme;
    private final View mEmojiPanel;

    ToolbarController(final LatinIME ime, final View inputView) {
        mIme = ime;
        mEmojiPanel = inputView.findViewById(R.id.pixel_emoji_panel);
        setOnClick(inputView, R.id.pixel_toolbar_emoji, new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                toggleEmojiPanel();
            }
        });
        setOnClick(inputView, R.id.pixel_toolbar_clipboard, new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                pasteFromClipboard();
            }
        });
        setOnClick(inputView, R.id.pixel_toolbar_language, new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                mIme.switchToNextSubtype();
            }
        });
        setOnClick(inputView, R.id.pixel_toolbar_settings, new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                mIme.launchSettings();
            }
        });
        setOnClick(inputView, R.id.pixel_toolbar_mic, new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                mIme.startVoiceInput();
            }
        });
        setOnClick(inputView, R.id.pixel_emoji_abc, new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                hideEmojiPanel();
            }
        });
        setOnClick(inputView, R.id.pixel_emoji_delete, new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                mIme.onCodeInput(Constants.CODE_DELETE, Constants.NOT_A_COORDINATE,
                        Constants.NOT_A_COORDINATE, false);
            }
        });
        final View gridView = inputView.findViewById(R.id.pixel_emoji_grid);
        if (gridView instanceof GridView) {
            final GridView grid = (GridView) gridView;
            grid.setAdapter(new EmojiAdapter(ime));
            grid.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(final android.widget.AdapterView<?> parent, final View view,
                        final int position, final long id) {
                    mIme.onTextInput(EMOJIS[position]);
                }
            });
        }
    }

    private static void setOnClick(final View root, final int id,
            final View.OnClickListener listener) {
        final View v = root.findViewById(id);
        if (v != null) {
            v.setOnClickListener(listener);
        }
    }

    void hideEmojiPanel() {
        if (mEmojiPanel != null) {
            mEmojiPanel.setVisibility(View.GONE);
        }
    }

    private void toggleEmojiPanel() {
        if (mEmojiPanel == null) {
            return;
        }
        mEmojiPanel.setVisibility(
                mEmojiPanel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    private void pasteFromClipboard() {
        final ClipboardManager cm =
                (ClipboardManager) mIme.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip()) {
            return;
        }
        final ClipData clip = cm.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) {
            return;
        }
        final CharSequence text = clip.getItemAt(0).coerceToText(mIme);
        if (!TextUtils.isEmpty(text)) {
            mIme.onTextInput(text.toString());
        }
    }

    private static final class EmojiAdapter extends BaseAdapter {
        private final Context mContext;
        private final int mCellHeight;

        EmojiAdapter(final Context context) {
            mContext = context;
            mCellHeight = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 44,
                    context.getResources().getDisplayMetrics());
        }

        @Override
        public int getCount() {
            return EMOJIS.length;
        }

        @Override
        public Object getItem(final int position) {
            return EMOJIS[position];
        }

        @Override
        public long getItemId(final int position) {
            return position;
        }

        @Override
        public View getView(final int position, final View convertView, final ViewGroup parent) {
            final TextView tv;
            if (convertView instanceof TextView) {
                tv = (TextView) convertView;
            } else {
                tv = new TextView(mContext);
                tv.setGravity(Gravity.CENTER);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
                tv.setLayoutParams(new GridView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, mCellHeight));
            }
            tv.setText(EMOJIS[position]);
            return tv;
        }
    }
}
