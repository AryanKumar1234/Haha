package com.abifog.lokiboard.latin;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;

import com.abifog.lokiboard.R;
import com.abifog.lokiboard.event.Event;
import com.abifog.lokiboard.keyboard.KeyboardId;
import com.abifog.lokiboard.latin.common.Constants;
import com.abifog.lokiboard.latin.swipe.SwipeDecoder;
import com.abifog.lokiboard.latin.swipe.SwipeWordList;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Swipe ("glide") typing: owns the dictionary and decoder, commits swiped words, shows the
 * suggestion strip, and learns the words the user picks.
 */
public final class SwipeTyping {
    private static final String TAG = "SwipeTyping";
    public static final String PREF_ENABLED = "pref_pixel_swipe_typing";
    private static final String STORE_NAME = "pixel_toolbar";
    private static final String PREF_LEARNED = "swipe_learned";
    private static final int MAX_LEARNED = 3000;
    private static final String PUNCTUATION = ".,!?;:";
    private static final String NO_SPACE_BEFORE = "([{\u201c\"'/@#-\u2018";

    private static SwipeTyping sInstance;

    public static SwipeTyping get() {
        return sInstance;
    }

    private final LatinIME mIme;
    private final SharedPreferences mSettings;
    private final SharedPreferences mStore;
    private final Map<String, Integer> mLearned = new HashMap<String, Integer>();
    private volatile SwipeDecoder mDecoder;

    // geometry handed over by the keyboard view
    private Object mGeometryOwner;
    private boolean mGeometryDirty;
    private float[] mCx;
    private float[] mCy;
    private boolean[] mPresent;
    private float mUnit = 1f;

    // suggestion strip
    private View mToolbar;
    private View mStrip;
    private final TextView[] mSlots = new TextView[3];
    private final String[] mSlotRaw = new String[3];     // dictionary form
    private final String[] mSlotShown = new String[3];   // with capitalisation applied
    private int mShiftElement = KeyboardId.ELEMENT_ALPHABET;

    // last committed swipe
    private String mLastCommitted;   // exact text inserted: prefix + word + trailing space
    private String mLastPrefix = "";
    private String mLastRaw;         // dictionary form of the committed word
    private boolean mInternalEdit;

    public SwipeTyping(final LatinIME ime) {
        mIme = ime;
        mSettings = android.preference.PreferenceManager.getDefaultSharedPreferences(ime);
        mStore = ime.getSharedPreferences(STORE_NAME, Context.MODE_PRIVATE);
        sInstance = this;
        loadLearned();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final InputStream in = mIme.getResources().openRawResource(R.raw.swipe_words);
                    final SwipeWordList list = SwipeWordList.load(in);
                    in.close();
                    final SwipeDecoder decoder = new SwipeDecoder(list);
                    decoder.setLearned(mLearned);
                    mGeometryDirty = true;
                    mDecoder = decoder;
                } catch (final Exception e) {
                    Log.w(TAG, "Could not load the swipe dictionary", e);
                }
            }
        }, "swipe-dictionary").start();
    }

    // ------------------------------------------------------------------ keyboard side API

    public boolean isEnabled() {
        return mDecoder != null && mSettings.getBoolean(PREF_ENABLED, true);
    }

    public boolean needsGeometry(final Object owner) {
        return owner != mGeometryOwner;
    }

    public void setGeometry(final Object owner, final float[] cx, final float[] cy,
            final boolean[] present, final float unit) {
        mGeometryOwner = owner;
        mCx = cx;
        mCy = cy;
        mPresent = present;
        mUnit = unit;
        mGeometryDirty = true;
    }

    public List<SwipeDecoder.Candidate> decode(final float[] x, final float[] y, final int count,
            final int max) {
        final SwipeDecoder decoder = mDecoder;
        if (decoder == null || mCx == null) {
            return new ArrayList<SwipeDecoder.Candidate>();
        }
        if (mGeometryDirty) {
            decoder.setGeometry(mCx, mCy, mPresent, mUnit);
            mGeometryDirty = false;
        }
        return decoder.decode(x, y, count, max);
    }

    /** Shows the best guess while the finger is still down. */
    public void showPreview(final String word, final int shiftElement) {
        if (mStrip == null) {
            return;
        }
        for (int i = 0; i < 3; i++) {
            mSlotRaw[i] = null;
            mSlotShown[i] = null;
        }
        if (word != null) {
            mSlotRaw[1] = word;
            mSlotShown[1] = applyCase(word, shiftElement);
        }
        renderStrip(false);
    }

    /** Called when the finger is lifted: types the best word and offers alternatives. */
    public void commitSwipe(final List<SwipeDecoder.Candidate> candidates, final int shiftElement) {
        if (candidates == null || candidates.isEmpty()) {
            hideStrip();
            return;
        }
        final InputConnection ic = mIme.getCurrentInputConnection();
        if (ic == null) {
            hideStrip();
            return;
        }
        acceptPrevious();
        mShiftElement = shiftElement;
        final String best = candidates.get(0).word;
        final String shown = applyCase(best, shiftElement);
        final String prefix = needsLeadingSpace(ic) ? " " : "";
        final String text = prefix + shown + " ";

        mInternalEdit = true;
        try {
            mIme.onTextInput(text);
        } finally {
            mInternalEdit = false;
        }
        mLastCommitted = text;
        mLastPrefix = prefix;
        mLastRaw = best;

        // alternatives: [alt1, best, alt2]
        for (int i = 0; i < 3; i++) {
            mSlotRaw[i] = null;
            mSlotShown[i] = null;
        }
        mSlotRaw[1] = best;
        mSlotShown[1] = shown;
        int filled = 0;
        for (int i = 1; i < candidates.size() && filled < 2; i++) {
            final String alt = candidates.get(i).word;
            if (alt.equals(best)) {
                continue;
            }
            final int slot = filled == 0 ? 0 : 2;
            mSlotRaw[slot] = alt;
            mSlotShown[slot] = applyCase(alt, shiftElement);
            filled++;
        }
        renderStrip(true);
    }

    // ------------------------------------------------------------------ input events

    /** Returns true when the event has been fully handled here. */
    public boolean onKeyEvent(final Event event) {
        if (mInternalEdit) {
            return false;
        }
        final boolean isDelete = event.mKeyCode == Constants.CODE_DELETE;
        final boolean isChar = event.mCodePoint > 0;
        final boolean isEnter = event.mKeyCode == Constants.CODE_ENTER
                || event.mCodePoint == Constants.CODE_ENTER;
        if (!isDelete && !isChar && !isEnter) {
            return false;
        }
        if (mLastCommitted == null) {
            hideStripIfPreview();
            return false;
        }
        if (isDelete) {
            // Backspace right after a swipe removes the whole swiped word.
            final boolean intact = textBeforeCursorEquals(mLastCommitted);
            final int length = mLastCommitted.length();
            clearLast();
            hideStrip();
            if (intact) {
                deleteChars(length);
                return true;
            }
            return false;
        }
        if (event.mCodePoint == Constants.CODE_SPACE && textBeforeCursorEquals(mLastCommitted)) {
            // The swiped word already ends with a space.
            acceptPrevious();
            clearLast();
            hideStrip();
            return true;
        }
        if (isChar && PUNCTUATION.indexOf(event.mCodePoint) >= 0
                && textBeforeCursorEquals(mLastCommitted)) {
            deleteChars(1); // remove the automatic space before the punctuation
        }
        acceptPrevious();
        clearLast();
        hideStrip();
        return false;
    }

    public void reset() {
        clearLast();
        hideStrip();
    }

    private void clearLast() {
        mLastCommitted = null;
        mLastRaw = null;
        mLastPrefix = "";
    }

    private void acceptPrevious() {
        if (mLastRaw != null) {
            learn(mLastRaw, 1);
        }
    }

    // ------------------------------------------------------------------ editing helpers

    private boolean needsLeadingSpace(final InputConnection ic) {
        final CharSequence before = ic.getTextBeforeCursor(1, 0);
        if (before == null || before.length() == 0) {
            return false;
        }
        final char c = before.charAt(0);
        return !Character.isWhitespace(c) && NO_SPACE_BEFORE.indexOf(c) < 0;
    }

    private boolean textBeforeCursorEquals(final String expected) {
        final InputConnection ic = mIme.getCurrentInputConnection();
        if (ic == null) {
            return false;
        }
        final CharSequence before = ic.getTextBeforeCursor(expected.length(), 0);
        return before != null && expected.contentEquals(before);
    }

    private void deleteChars(final int count) {
        mInternalEdit = true;
        try {
            for (int i = 0; i < count; i++) {
                mIme.onEvent(LatinIME.createSoftwareKeypressEvent(Constants.CODE_DELETE,
                        Constants.NOT_A_COORDINATE, Constants.NOT_A_COORDINATE, false));
            }
        } finally {
            mInternalEdit = false;
        }
    }

    private static String applyCase(final String word, final int element) {
        switch (element) {
        case KeyboardId.ELEMENT_ALPHABET_SHIFT_LOCKED:
        case KeyboardId.ELEMENT_ALPHABET_SHIFT_LOCK_SHIFTED:
            return word.toUpperCase();
        case KeyboardId.ELEMENT_ALPHABET_MANUAL_SHIFTED:
        case KeyboardId.ELEMENT_ALPHABET_AUTOMATIC_SHIFTED:
            return word.length() == 0 ? word
                    : word.substring(0, 1).toUpperCase() + word.substring(1);
        default:
            return word;
        }
    }

    // ------------------------------------------------------------------ suggestion strip

    public void attachStrip(final View root) {
        mToolbar = root.findViewById(R.id.pixel_toolbar);
        mStrip = root.findViewById(R.id.pixel_suggestion_strip);
        final int[] ids = {R.id.pixel_sug_0, R.id.pixel_sug_1, R.id.pixel_sug_2};
        for (int i = 0; i < 3; i++) {
            final int slot = i;
            mSlots[i] = (TextView) root.findViewById(ids[i]);
            if (mSlots[i] != null) {
                mSlots[i].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(final View v) {
                        onSlotTapped(slot);
                    }
                });
            }
        }
        reset();
    }

    private void renderStrip(final boolean interactive) {
        if (mStrip == null || mToolbar == null) {
            return;
        }
        for (int i = 0; i < 3; i++) {
            if (mSlots[i] == null) {
                continue;
            }
            mSlots[i].setText(mSlotShown[i] == null ? "" : mSlotShown[i]);
            mSlots[i].setClickable(interactive && mSlotShown[i] != null);
            mSlots[i].setTypeface(null, i == 1 ? android.graphics.Typeface.BOLD
                    : android.graphics.Typeface.NORMAL);
        }
        mToolbar.setVisibility(View.INVISIBLE);
        mStrip.setVisibility(View.VISIBLE);
    }

    private void hideStrip() {
        if (mStrip != null) {
            mStrip.setVisibility(View.GONE);
        }
        if (mToolbar != null) {
            mToolbar.setVisibility(View.VISIBLE);
        }
    }

    private void hideStripIfPreview() {
        if (mStrip != null && mStrip.getVisibility() == View.VISIBLE) {
            hideStrip();
        }
    }

    private void onSlotTapped(final int slot) {
        final String raw = mSlotRaw[slot];
        final String shown = mSlotShown[slot];
        if (raw == null || shown == null || mLastCommitted == null) {
            return;
        }
        if (slot != 1) {
            if (!textBeforeCursorEquals(mLastCommitted)) {
                clearLast();
                hideStrip();
                return;
            }
            final int length = mLastCommitted.length();
            deleteChars(length);
            final String text = mLastPrefix + shown + " ";
            mInternalEdit = true;
            try {
                mIme.onTextInput(text);
            } finally {
                mInternalEdit = false;
            }
            learn(raw, 2);
            // swap the chosen word with the previous best
            final String oldRaw = mSlotRaw[1];
            final String oldShown = mSlotShown[1];
            mSlotRaw[1] = raw;
            mSlotShown[1] = shown;
            mSlotRaw[slot] = oldRaw;
            mSlotShown[slot] = oldShown;
            mLastCommitted = text;
            mLastRaw = raw;
            renderStrip(true);
        } else {
            acceptPrevious();
            clearLast();
            hideStrip();
        }
    }

    // ------------------------------------------------------------------ learning

    private void learn(final String word, final int amount) {
        final Integer old = mLearned.get(word);
        mLearned.put(word, (old == null ? 0 : old) + amount);
        if (mLearned.size() > MAX_LEARNED) {
            String weakest = null;
            int weakestCount = Integer.MAX_VALUE;
            for (final Map.Entry<String, Integer> e : mLearned.entrySet()) {
                if (e.getValue() < weakestCount) {
                    weakestCount = e.getValue();
                    weakest = e.getKey();
                }
            }
            if (weakest != null) {
                mLearned.remove(weakest);
            }
        }
        final StringBuilder sb = new StringBuilder();
        for (final Map.Entry<String, Integer> e : mLearned.entrySet()) {
            if (sb.length() > 0) {
                sb.append('\u0002');
            }
            sb.append(e.getKey()).append('\u0001').append(e.getValue());
        }
        mStore.edit().putString(PREF_LEARNED, sb.toString()).apply();
    }

    private void loadLearned() {
        final String saved = mStore.getString(PREF_LEARNED, "");
        if (saved == null || saved.isEmpty()) {
            return;
        }
        for (final String part : saved.split("\u0002")) {
            final int sep = part.indexOf('\u0001');
            if (sep <= 0) {
                continue;
            }
            try {
                mLearned.put(part.substring(0, sep), Integer.valueOf(part.substring(sep + 1)));
            } catch (final NumberFormatException e) {
                // ignore a damaged entry
            }
        }
    }
}
