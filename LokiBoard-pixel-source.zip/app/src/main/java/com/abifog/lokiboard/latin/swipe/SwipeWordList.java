package com.abifog.lokiboard.latin.swipe;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * Word list used by the swipe decoder: display form, letters-only key form and a popularity
 * score (higher = more common). Words are bucketed by first and last letter.
 */
public final class SwipeWordList {
    public final String[] display;
    public final String[] keys;
    public final short[] score;
    final int[][] buckets;

    private SwipeWordList(final String[] display, final String[] keys, final short[] score) {
        this.display = display;
        this.keys = keys;
        this.score = score;
        final int n = display.length;
        final int[] counts = new int[26 * 26];
        for (int i = 0; i < n; i++) {
            counts[bucketOf(keys[i])]++;
        }
        buckets = new int[26 * 26][];
        for (int b = 0; b < buckets.length; b++) {
            buckets[b] = new int[counts[b]];
        }
        final int[] fill = new int[26 * 26];
        for (int i = 0; i < n; i++) {
            final int b = bucketOf(keys[i]);
            buckets[b][fill[b]++] = i;
        }
    }

    private static int bucketOf(final String key) {
        return (key.charAt(0) - 'a') * 26 + (key.charAt(key.length() - 1) - 'a');
    }

    public int size() {
        return display.length;
    }

    /** Lines are "display<TAB>score". Words that cannot be swiped (fewer than 2 letters) are skipped. */
    public static SwipeWordList load(final InputStream in) throws IOException {
        final BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"), 1 << 16);
        final ArrayList<String> disp = new ArrayList<String>(120000);
        final ArrayList<String> keys = new ArrayList<String>(120000);
        final ArrayList<Short> scores = new ArrayList<Short>(120000);
        String line;
        while ((line = reader.readLine()) != null) {
            final int tab = line.indexOf('\t');
            if (tab <= 0) {
                continue;
            }
            final String word = line.substring(0, tab);
            final short s;
            try {
                s = Short.parseShort(line.substring(tab + 1).trim());
            } catch (final NumberFormatException e) {
                continue;
            }
            final StringBuilder key = new StringBuilder(word.length());
            for (int i = 0; i < word.length(); i++) {
                final char c = Character.toLowerCase(word.charAt(i));
                if (c >= 'a' && c <= 'z') {
                    key.append(c);
                }
            }
            if (key.length() < 2) {
                continue;
            }
            disp.add(word);
            final String k = key.toString();
            keys.add(k.equals(word) ? word : k);
            scores.add(s);
        }
        reader.close();
        final int n = disp.size();
        final short[] sc = new short[n];
        for (int i = 0; i < n; i++) {
            sc[i] = scores.get(i);
        }
        return new SwipeWordList(disp.toArray(new String[n]), keys.toArray(new String[n]), sc);
    }
}
