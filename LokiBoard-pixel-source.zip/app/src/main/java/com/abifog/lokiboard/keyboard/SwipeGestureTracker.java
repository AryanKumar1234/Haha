package com.abifog.lokiboard.keyboard;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.MotionEvent;

import com.abifog.lokiboard.R;
import com.abifog.lokiboard.latin.SwipeTyping;
import com.abifog.lokiboard.latin.swipe.SwipeDecoder;

import java.util.Arrays;
import java.util.List;

/**
 * Detects a swipe that starts on a letter key, records it, draws the trail and hands the path to
 * {@link SwipeTyping}. Taps and slow/short movements are left to the normal key handling.
 */
final class SwipeGestureTracker {
    private static final int IDLE = 0;
    private static final int PENDING = 1;
    private static final int SWIPING = 2;
    private static final float START_DISTANCE = 1.0f;   // key widths from the touch-down point
    private static final float START_KEY_RADIUS = 0.85f;
    private static final long PREVIEW_INTERVAL_MS = 90;
    private static final int TRAIL_POINTS = 44;

    private int mState = IDLE;

    // key-space coordinates (what the decoder sees) and view-space coordinates (for drawing)
    private float[] mKx = new float[256];
    private float[] mKy = new float[256];
    private float[] mVx = new float[256];
    private float[] mVy = new float[256];
    private int mCount;

    private Keyboard mGeoKeyboard;
    private boolean mLetterKeyboard;
    private float[] mLetterX = new float[26];
    private float[] mLetterY = new float[26];
    private boolean[] mLetterPresent = new boolean[26];
    private float mUnit = 1f;

    private long mLastPreview;
    private Paint mPaint;

    boolean onTouchEvent(final MainKeyboardView view, final MotionEvent event) {
        final SwipeTyping swipe = SwipeTyping.get();
        final int action = event.getActionMasked();

        if (mState == SWIPING) {
            switch (action) {
            case MotionEvent.ACTION_MOVE:
                addHistory(view, event);
                addPoint(view, event.getX(), event.getY());
                updatePreview(view, swipe, event.getEventTime());
                view.invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                addHistory(view, event);
                addPoint(view, event.getX(), event.getY());
                finish(view, swipe);
                return true;
            case MotionEvent.ACTION_CANCEL:
                reset(view);
                return true;
            default:
                return true; // ignore additional fingers while swiping
            }
        }

        switch (action) {
        case MotionEvent.ACTION_DOWN:
            reset(null);
            if (swipe == null || !swipe.isEnabled() || event.getPointerCount() != 1
                    || view.isShowingMoreKeysPanel()) {
                return false;
            }
            if (!prepareGeometry(view, swipe)) {
                return false;
            }
            addPoint(view, event.getX(), event.getY());
            if (nearestLetterDistance(mKx[0], mKy[0]) > START_KEY_RADIUS) {
                reset(null);
                return false;
            }
            mState = PENDING;
            return false;
        case MotionEvent.ACTION_MOVE:
            if (mState != PENDING) {
                return false;
            }
            if (event.getPointerCount() != 1 || view.isShowingMoreKeysPanel()) {
                reset(null);
                return false;
            }
            addHistory(view, event);
            addPoint(view, event.getX(), event.getY());
            final float dx = mKx[mCount - 1] - mKx[0];
            final float dy = mKy[mCount - 1] - mKy[0];
            if (Math.sqrt(dx * dx + dy * dy) / mUnit > START_DISTANCE) {
                startSwiping(view, swipe, event);
                return true;
            }
            return false;
        case MotionEvent.ACTION_UP:
        case MotionEvent.ACTION_CANCEL:
        case MotionEvent.ACTION_POINTER_DOWN:
            reset(null);
            return false;
        default:
            return false;
        }
    }

    private void startSwiping(final MainKeyboardView view, final SwipeTyping swipe,
            final MotionEvent event) {
        mState = SWIPING;
        // Cancel the key that is currently pressed so that nothing is typed for it.
        final MotionEvent cancel = MotionEvent.obtain(event.getDownTime(), event.getEventTime(),
                MotionEvent.ACTION_CANCEL, event.getX(), event.getY(), 0);
        view.handleTouchEvent(cancel);
        cancel.recycle();
        mLastPreview = 0;
        updatePreview(view, swipe, event.getEventTime());
        view.invalidate();
    }

    private void finish(final MainKeyboardView view, final SwipeTyping swipe) {
        final int shiftElement = view.getKeyboard().mId.mElementId;
        if (swipe != null) {
            final List<SwipeDecoder.Candidate> candidates = swipe.decode(mKx, mKy, mCount, 5);
            swipe.commitSwipe(candidates, shiftElement);
        }
        reset(view);
    }

    private void updatePreview(final MainKeyboardView view, final SwipeTyping swipe,
            final long eventTime) {
        if (swipe == null || eventTime - mLastPreview < PREVIEW_INTERVAL_MS || mCount < 4) {
            return;
        }
        mLastPreview = eventTime;
        final List<SwipeDecoder.Candidate> c = swipe.decode(mKx, mKy, mCount, 1);
        swipe.showPreview(c.isEmpty() ? null : c.get(0).word,
                view.getKeyboard().mId.mElementId);
    }

    private void reset(final MainKeyboardView viewToRedraw) {
        final boolean wasSwiping = mState == SWIPING;
        mState = IDLE;
        mCount = 0;
        if (viewToRedraw != null && wasSwiping) {
            viewToRedraw.invalidate();
        }
    }

    // ------------------------------------------------------------------ geometry

    private boolean prepareGeometry(final MainKeyboardView view, final SwipeTyping swipe) {
        final Keyboard keyboard = view.getKeyboard();
        if (keyboard == null) {
            return false;
        }
        if (keyboard != mGeoKeyboard) {
            mGeoKeyboard = keyboard;
            Arrays.fill(mLetterPresent, false);
            int letters = 0;
            for (final Key key : keyboard.getSortedKeys()) {
                final int code = key.getCode();
                if (code <= 0) {
                    continue;
                }
                final int lower = Character.toLowerCase(code);
                if (lower < 'a' || lower > 'z') {
                    continue;
                }
                final int index = lower - 'a';
                if (!mLetterPresent[index]) {
                    letters++;
                }
                mLetterPresent[index] = true;
                mLetterX[index] = key.getX() + key.getWidth() / 2f;
                mLetterY[index] = key.getY() + key.getHeight() / 2f;
            }
            mLetterKeyboard = letters >= 20;
            mUnit = computePitch(keyboard);
            if (mLetterKeyboard) {
                swipe.setGeometry(keyboard, mLetterX.clone(), mLetterY.clone(),
                        mLetterPresent.clone(), mUnit);
            }
        }
        return mLetterKeyboard;
    }

    /** Distance between neighbouring key centres in the same row, in pixels. */
    private static final String[] PITCH_PAIRS = {
        "qw", "we", "er", "rt", "ty", "as", "sd", "df", "fg", "gh", "zx", "xc", "cv", "vb"
    };

    /** Distance between neighbouring key centres in the same row, in pixels. */
    private float computePitch(final Keyboard keyboard) {
        float sum = 0;
        int n = 0;
        for (final String pair : PITCH_PAIRS) {
            final int a = pair.charAt(0) - 'a';
            final int b = pair.charAt(1) - 'a';
            if (mLetterPresent[a] && mLetterPresent[b]
                    && Math.abs(mLetterY[a] - mLetterY[b]) < 1f) {
                sum += Math.abs(mLetterX[a] - mLetterX[b]);
                n++;
            }
        }
        if (n > 0 && sum / n > 4) {
            return sum / n;
        }
        return Math.max(1, keyboard.mMostCommonKeyWidth);
    }

    private float nearestLetterDistance(final float x, final float y) {
        float best = Float.MAX_VALUE;
        for (int i = 0; i < 26; i++) {
            if (!mLetterPresent[i]) {
                continue;
            }
            final float dx = x - mLetterX[i];
            final float dy = y - mLetterY[i];
            final float d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d < best) {
                best = d;
            }
        }
        return best / mUnit;
    }

    // ------------------------------------------------------------------ points and drawing

    private void addHistory(final MainKeyboardView view, final MotionEvent event) {
        final int n = event.getHistorySize();
        for (int h = 0; h < n; h++) {
            addPoint(view, event.getHistoricalX(h), event.getHistoricalY(h));
        }
    }

    private void addPoint(final MainKeyboardView view, final float x, final float y) {
        if (mCount == mKx.length) {
            if (mCount >= 4096) {
                return;
            }
            final int size = mCount * 2;
            mKx = Arrays.copyOf(mKx, size);
            mKy = Arrays.copyOf(mKy, size);
            mVx = Arrays.copyOf(mVx, size);
            mVy = Arrays.copyOf(mVy, size);
        }
        mVx[mCount] = x;
        mVy[mCount] = y;
        mKx[mCount] = view.getKeyX((int) x);
        mKy[mCount] = view.getKeyY((int) y);
        mCount++;
    }

    void draw(final MainKeyboardView view, final Canvas canvas) {
        if (mState != SWIPING || mCount < 2) {
            return;
        }
        if (mPaint == null) {
            mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            mPaint.setStyle(Paint.Style.STROKE);
            mPaint.setStrokeCap(Paint.Cap.ROUND);
            mPaint.setStrokeWidth(view.getResources().getDisplayMetrics().density * 5f);
        }
        final int color = view.getResources().getColor(R.color.pixel_tab_bg);
        final int rgb = color & 0x00FFFFFF;
        final int first = Math.max(0, mCount - TRAIL_POINTS);
        for (int i = first + 1; i < mCount; i++) {
            final float t = (i - first) / (float) (mCount - first);
            mPaint.setColor(((int) (40 + 215 * t) << 24) | rgb);
            canvas.drawLine(mVx[i - 1], mVy[i - 1], mVx[i], mVy[i], mPaint);
        }
    }
}
