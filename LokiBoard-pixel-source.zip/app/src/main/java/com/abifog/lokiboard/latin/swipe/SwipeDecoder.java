package com.abifog.lokiboard.latin.swipe;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Shape/location based swipe ("gesture") word decoder.
 *
 * <p>The gesture is resampled and compared (banded dynamic time warping) with the ideal path of
 * every candidate word, i.e. the polyline through its key centres. Candidates are pruned by the
 * keys near the start and the end of the gesture, then scored on location error, whether every
 * letter of the word was visited, whether every sharp turn of the gesture is explained by a letter
 * of the word, path length plausibility and word popularity.</p>
 */
public final class SwipeDecoder {
    public static final class Candidate {
        public final String word;
        public final String key;
        public final float cost;

        Candidate(final String word, final String key, final float cost) {
            this.word = word;
            this.key = key;
            this.cost = cost;
        }
    }

    // ---- tunable weights (see SwipeTuning in the offline test harness)
    public float wDtw = 1.5f;
    public float wCover = 1.35f;
    public float wCorner = 0.9f;
    public float wEnds = 1.0f;
    public float wLength = 0.65f;
    public float wLm = 0.03f;
    public float wLearned = 0.5f;

    private static final int N = 32;     // points used by the DTW
    private static final int M = 72;     // points used by the coverage / corner checks
    private static final int BAND = 6;
    public float tunnel = 0.30f;
    private static final float END_RADIUS = 1.30f;
    public float coverRadius = 0.62f;
    public float cornerRadius = 0.62f;
    public float cornerAngle = 1.3f;  // ~60 degrees
    public float idealRatio = 0.88f;

    private final SwipeWordList mWords;
    private final float[] mKx = new float[26];
    private final float[] mKy = new float[26];
    private final boolean[] mHas = new boolean[26];
    private float mUnit = 1f;
    private final HashMap<Integer, float[]> mTemplates = new HashMap<Integer, float[]>();
    private Map<String, Integer> mLearned;

    public SwipeDecoder(final SwipeWordList words) {
        mWords = words;
    }

    public void setLearned(final Map<String, Integer> learned) {
        mLearned = learned;
    }

    /** Key centres in pixels (any consistent unit); {@code keyWidth} is the typical key pitch. */
    public void setGeometry(final float[] cx, final float[] cy, final boolean[] present,
            final float keyWidth) {
        mUnit = keyWidth;
        for (int i = 0; i < 26; i++) {
            mHas[i] = present[i];
            mKx[i] = cx[i] / keyWidth;
            mKy[i] = cy[i] / keyWidth;
        }
        mTemplates.clear();
    }

    // ------------------------------------------------------------------ decoding

    public List<Candidate> decode(final float[] px, final float[] py, final int count,
            final int maxResults) {
        final List<Candidate> result = new ArrayList<Candidate>();
        if (count < 2) {
            return result;
        }
        // normalise to key widths, drop duplicates, light smoothing
        float[] gx = new float[count];
        float[] gy = new float[count];
        int n = 0;
        for (int i = 0; i < count; i++) {
            final float x = px[i] / mUnit;
            final float y = py[i] / mUnit;
            if (n > 0 && dist(x, y, gx[n - 1], gy[n - 1]) < 0.04f) {
                continue;
            }
            gx[n] = x;
            gy[n] = y;
            n++;
        }
        if (n < 2) {
            return result;
        }
        smooth(gx, gy, n);
        final float length = pathLength(gx, gy, n);
        if (length < 1.0f) {
            return result;
        }
        final float[] g = resample(gx, gy, n, N);
        final float[] d = resample(gx, gy, n, M);
        final float[] corners = findCorners(d);

        final int[] starts = nearKeys(gx[0], gy[0]);
        final int[] ends = nearKeys(gx[n - 1], gy[n - 1]);

        final int k = Math.max(1, maxResults);
        final int[] bestIdx = new int[k];
        final float[] bestCost = new float[k];
        int found = 0;
        final float[] prev = new float[N];
        final float[] curr = new float[N];

        for (final int s : starts) {
            for (final int e : ends) {
                final int[] bucket = mWords.buckets[s * 26 + e];
                for (final int w : bucket) {
                    final String key = mWords.keys[w];
                    final float[] t = template(w, key);
                    if (t == null) {
                        continue;
                    }
                    final float tLen = t[2 * N];
                    final float ratio = length / tLen;
                    if (ratio < 0.5f || ratio > 1.9f) {
                        continue;
                    }
                    float cost = lmCost(w) + wLength * sq((float) Math.log(ratio / idealRatio));
                    final float endsCost = wEnds * (dist(g[0], g[1], t[0], t[1])
                            + dist(g[2 * N - 2], g[2 * N - 1], t[2 * N - 2], t[2 * N - 1]));
                    cost += endsCost;
                    if (found == k && cost > bestCost[found - 1]) {
                        continue;
                    }
                    cost += wDtw * dtw(g, t, prev, curr);
                    if (found == k && cost > bestCost[found - 1]) {
                        continue;
                    }
                    cost += letterChecks(key, d, corners);
                    if (found == k && cost >= bestCost[found - 1]) {
                        continue;
                    }
                    // insert sorted
                    int pos = found < k ? found : k - 1;
                    while (pos > 0 && bestCost[pos - 1] > cost) {
                        bestCost[pos] = bestCost[pos - 1];
                        bestIdx[pos] = bestIdx[pos - 1];
                        pos--;
                    }
                    bestCost[pos] = cost;
                    bestIdx[pos] = w;
                    if (found < k) {
                        found++;
                    }
                }
            }
        }
        for (int i = 0; i < found; i++) {
            result.add(new Candidate(mWords.display[bestIdx[i]], mWords.keys[bestIdx[i]],
                    bestCost[i]));
        }
        return result;
    }

    private float lmCost(final int w) {
        float s = mWords.score[w];
        if (mLearned != null) {
            final Integer c = mLearned.get(mWords.display[w]);
            if (c != null) {
                s += 22f * wLearned * (float) (Math.log(1 + c) / Math.log(2));
            }
        }
        return -wLm * s;
    }

    /** Keys within END_RADIUS of the point (at least the closest one). */
    private int[] nearKeys(final float x, final float y) {
        final int[] tmp = new int[26];
        int cnt = 0;
        int nearest = -1;
        float nd = Float.MAX_VALUE;
        for (int i = 0; i < 26; i++) {
            if (!mHas[i]) {
                continue;
            }
            final float dd = dist(x, y, mKx[i], mKy[i]);
            if (dd < nd) {
                nd = dd;
                nearest = i;
            }
            if (dd <= END_RADIUS) {
                tmp[cnt++] = i;
            }
        }
        if (cnt == 0 && nearest >= 0) {
            tmp[cnt++] = nearest;
        }
        final int[] out = new int[cnt];
        System.arraycopy(tmp, 0, out, 0, cnt);
        return out;
    }

    /** Ideal path of a word: [x0,y0, ... ] resampled to N points, plus its length at [2N]. */
    private float[] template(final int w, final String key) {
        final Integer id = Integer.valueOf(w);
        float[] t = mTemplates.get(id);
        if (t != null) {
            return t.length == 0 ? null : t;
        }
        final float[] cx = new float[key.length()];
        final float[] cy = new float[key.length()];
        int n = 0;
        for (int i = 0; i < key.length(); i++) {
            final int c = key.charAt(i) - 'a';
            if (!mHas[c]) {
                mTemplates.put(id, new float[0]);
                return null;
            }
            if (n > 0 && key.charAt(i) == key.charAt(i - 1)) {
                continue;
            }
            cx[n] = mKx[c];
            cy[n] = mKy[c];
            n++;
        }
        if (n < 2) {
            mTemplates.put(id, new float[0]);
            return null;
        }
        final float len = pathLength(cx, cy, n);
        final float[] r = resample(cx, cy, n, N);
        t = new float[2 * N + 1];
        System.arraycopy(r, 0, t, 0, 2 * N);
        t[2 * N] = len;
        if (mTemplates.size() > 12000) {
            mTemplates.clear();
        }
        mTemplates.put(id, t);
        return t;
    }

    /** Banded DTW with a tunnel (no cost while closer than TUNNEL), averaged per step. */
    private float dtw(final float[] g, final float[] t, final float[] prev,
            final float[] curr) {
        final float inf = 1e9f;
        for (int j = 0; j < N; j++) {
            prev[j] = inf;
        }
        for (int i = 0; i < N; i++) {
            final int lo = Math.max(0, i - BAND);
            final int hi = Math.min(N - 1, i + BAND);
            for (int j = 0; j < N; j++) {
                curr[j] = inf;
            }
            for (int j = lo; j <= hi; j++) {
                float c = dist(g[2 * i], g[2 * i + 1], t[2 * j], t[2 * j + 1]) - tunnel;
                if (c < 0) {
                    c = 0;
                }
                float best;
                if (i == 0 && j == 0) {
                    best = 0;
                } else {
                    best = inf;
                    if (i > 0 && prev[j] < best) {
                        best = prev[j];
                    }
                    if (j > 0 && curr[j - 1] < best) {
                        best = curr[j - 1];
                    }
                    if (i > 0 && j > 0 && prev[j - 1] < best) {
                        best = prev[j - 1];
                    }
                }
                curr[j] = best + c;
            }
            System.arraycopy(curr, 0, prev, 0, N);
        }
        return prev[N - 1] / N;
    }

    /** Coverage of the word's letters by the gesture and of the gesture's corners by the letters. */
    private float letterChecks(final String key, final float[] d, final float[] corners) {
        float cover = 0;
        final int len = key.length();
        int prevLetter = -1;
        final float[] lx = new float[len];
        final float[] ly = new float[len];
        int n = 0;
        for (int i = 0; i < len; i++) {
            final int c = key.charAt(i) - 'a';
            if (c == prevLetter) {
                continue;
            }
            prevLetter = c;
            lx[n] = mKx[c];
            ly[n] = mKy[c];
            n++;
        }
        for (int i = 0; i < n; i++) {
            float best = Float.MAX_VALUE;
            for (int j = 0; j < M; j++) {
                final float dd = dist(lx[i], ly[i], d[2 * j], d[2 * j + 1]);
                if (dd < best) {
                    best = dd;
                }
            }
            if (best > coverRadius) {
                cover += best - coverRadius;
            }
        }
        float corner = 0;
        for (int c = 0; c < corners.length; c += 2) {
            float best = Float.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                final float dd = dist(corners[c], corners[c + 1], lx[i], ly[i]);
                if (dd < best) {
                    best = dd;
                }
            }
            if (best > cornerRadius) {
                corner += best - cornerRadius;
            }
        }
        return wCover * cover + wCorner * corner;
    }

    /** Points of the (resampled) gesture where the direction changes sharply. */
    private float[] findCorners(final float[] d) {
        final int step = 3;
        final float[] tmp = new float[2 * M];
        int cnt = 0;
        float lastX = -100;
        float lastY = -100;
        for (int i = step; i < M - step; i++) {
            final float ax = d[2 * i] - d[2 * (i - step)];
            final float ay = d[2 * i + 1] - d[2 * (i - step) + 1];
            final float bx = d[2 * (i + step)] - d[2 * i];
            final float by = d[2 * (i + step) + 1] - d[2 * i + 1];
            final float la = (float) Math.sqrt(ax * ax + ay * ay);
            final float lb = (float) Math.sqrt(bx * bx + by * by);
            if (la < 1e-3f || lb < 1e-3f) {
                continue;
            }
            float cos = (ax * bx + ay * by) / (la * lb);
            if (cos > 1) {
                cos = 1;
            } else if (cos < -1) {
                cos = -1;
            }
            final float angle = (float) Math.acos(cos);
            if (angle < cornerAngle) {
                continue;
            }
            // keep the sharpest point of a run of corner points
            final float x = d[2 * i];
            final float y = d[2 * i + 1];
            if (cnt > 0 && dist(x, y, lastX, lastY) < 0.6f) {
                continue;
            }
            tmp[cnt++] = x;
            tmp[cnt++] = y;
            lastX = x;
            lastY = y;
        }
        final float[] out = new float[cnt];
        System.arraycopy(tmp, 0, out, 0, cnt);
        return out;
    }

    // ------------------------------------------------------------------ geometry helpers

    private static float sq(final float v) {
        return v * v;
    }

    private static float dist(final float x1, final float y1, final float x2, final float y2) {
        final float dx = x1 - x2;
        final float dy = y1 - y2;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static void smooth(final float[] x, final float[] y, final int n) {
        if (n < 4) {
            return;
        }
        float px = x[0];
        float py = y[0];
        for (int i = 1; i < n - 1; i++) {
            final float cx = x[i];
            final float cy = y[i];
            x[i] = (px + 2 * cx + x[i + 1]) / 4f;
            y[i] = (py + 2 * cy + y[i + 1]) / 4f;
            px = cx;
            py = cy;
        }
    }

    private static float pathLength(final float[] x, final float[] y, final int n) {
        float len = 0;
        for (int i = 1; i < n; i++) {
            len += dist(x[i], y[i], x[i - 1], y[i - 1]);
        }
        return len;
    }

    /** Resamples a polyline to {@code m} equally spaced points: [x0,y0,x1,y1,...]. */
    static float[] resample(final float[] x, final float[] y, final int n, final int m) {
        final float[] out = new float[2 * m];
        final float total = pathLength(x, y, n);
        if (total <= 0) {
            for (int i = 0; i < m; i++) {
                out[2 * i] = x[0];
                out[2 * i + 1] = y[0];
            }
            return out;
        }
        final float step = total / (m - 1);
        out[0] = x[0];
        out[1] = y[0];
        int outCount = 1;
        float target = step;
        float acc = 0;
        for (int i = 1; i < n && outCount < m; i++) {
            final float seg = dist(x[i], y[i], x[i - 1], y[i - 1]);
            while (outCount < m && acc + seg >= target - 1e-6f && seg > 0) {
                final float f = (target - acc) / seg;
                out[2 * outCount] = x[i - 1] + f * (x[i] - x[i - 1]);
                out[2 * outCount + 1] = y[i - 1] + f * (y[i] - y[i - 1]);
                outCount++;
                target += step;
            }
            acc += seg;
        }
        while (outCount < m) {
            out[2 * outCount] = x[n - 1];
            out[2 * outCount + 1] = y[n - 1];
            outCount++;
        }
        return out;
    }
}
