/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.onion.onioboard.latin.settings;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceScreen;

import com.onion.onioboard.R;
import com.onion.onioboard.latin.utils.ApplicationUtils;

public final class SettingsFragment extends InputMethodSettingsFragment {
    // Must match the android:name of the <activity-alias> in AndroidManifest.xml that carries
    // the LAUNCHER intent-filter (the home screen icon) for SettingsActivity.
    private static final String SETTINGS_LAUNCHER_ALIAS =
            "com.onion.onioboard.latin.settings.SettingsLauncherAlias";

    @Override
    public void onCreate(final Bundle icicle) {
        super.onCreate(icicle);
        setHasOptionsMenu(true);
        setInputMethodSettingsCategoryTitle(R.string.language_selection_title);
        setSubtypeEnablerTitle(R.string.select_language);
        addPreferencesFromResource(R.xml.prefs);
        final PreferenceScreen preferenceScreen = getPreferenceScreen();
        preferenceScreen.setTitle(
                ApplicationUtils.getActivityTitleResId(getActivity(), SettingsActivity.class));

        setupHideAppIconSettings();
    }

    private void setupHideAppIconSettings() {
        final CheckBoxPreference pref =
                (CheckBoxPreference)findPreference(Settings.PREF_HIDE_APP_ICON);
        if (pref == null) {
            return;
        }
        // Keep the checkbox in sync with the actual state of the launcher-icon component, in
        // case it was changed outside of this preference (e.g. re-installing the app resets it).
        pref.setChecked(!isLauncherIconEnabled(getActivity()));
        pref.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(final Preference preference, final Object newValue) {
                final boolean hide = (Boolean)newValue;
                setLauncherIconEnabled(getActivity(), !hide);
                return true;
            }
        });
    }

    /**
     * Enables or disables the launcher-icon alias for {@link SettingsActivity}. This only
     * affects whether the app shows an icon in the launcher; {@link SettingsActivity} itself
     * stays enabled so it remains reachable from the keyboard's settings key and from
     * Settings &gt; Languages &amp; input.
     */
    static void setLauncherIconEnabled(final Context context, final boolean enabled) {
        final PackageManager pm = context.getPackageManager();
        final ComponentName alias = new ComponentName(context, SETTINGS_LAUNCHER_ALIAS);
        pm.setComponentEnabledSetting(alias,
                enabled ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                        : PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP);
    }

    static boolean isLauncherIconEnabled(final Context context) {
        final PackageManager pm = context.getPackageManager();
        final ComponentName alias = new ComponentName(context, SETTINGS_LAUNCHER_ALIAS);
        final int state = pm.getComponentEnabledSetting(alias);
        return state != PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
    }
}
