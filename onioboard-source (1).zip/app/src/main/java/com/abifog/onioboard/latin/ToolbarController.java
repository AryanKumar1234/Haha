package com.abifog.onioboard.latin;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputConnection;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.abifog.onioboard.R;
import com.abifog.onioboard.latin.common.Constants;

import java.util.ArrayList;
import java.util.List;

/**
 * Gboard-style toolbar above the keyboard plus its panels: the quick menu, the text editing
 * panel and the categorized emoji panel.
 */
final class ToolbarController {
    private static final int CATEGORY_COUNT = 10; // recent + 9 categories
    private static final int EMOJI_COLUMNS = 8;
    private static final int KAOMOJI_COLUMNS = 3;
    private static final int MAX_RECENT = 24;
    private static final String PREFS_NAME = "pixel_toolbar";
    private static final String PREF_RECENT = "recent_emoji";

    private static final int[] TAB_IDS = {
        R.id.pixel_tab_0, R.id.pixel_tab_1, R.id.pixel_tab_2, R.id.pixel_tab_3,
        R.id.pixel_tab_4, R.id.pixel_tab_5, R.id.pixel_tab_6, R.id.pixel_tab_7,
        R.id.pixel_tab_8, R.id.pixel_tab_9
    };
    private static final int[] CATEGORY_RES = {
        0, R.string.emoji_smileys, R.string.emoji_people, R.string.emoji_animals,
        R.string.emoji_food, R.string.emoji_travel, R.string.emoji_activities,
        R.string.emoji_objects, R.string.emoji_symbols, R.string.emoji_flags
    };
    private static final String[] CATEGORY_TITLES = {
        "Recent emoji", "Smileys and emotions", "People and body", "Animals and nature",
        "Food and drink", "Travel and places", "Activities and events", "Objects",
        "Symbols", "Flags"
    };
    private static final String[] KAOMOJI = {
            ":-)",
            ";-)",
            ":-D",
            ":-P",
            "XD",
            ":-(",
            ":'(",
            ":-O",
            "<3",
            "^_^",
            "-_-",
            "o_O",
            "T_T",
            "(\u00AC_\u00AC)",
            "\u00AF\\_(\u30C4)_/\u00AF",
            "(\u256F\u00B0\u25A1\u00B0)\u256F\uFE35 \u253B\u2501\u253B",
            "\u0295\u2022\u1D25\u2022\u0294",
            "(\u3065\uFF61\u25D5\u203F\u203F\u25D5\uFF61)\u3065",
            "\u0CA0_\u0CA0",
            "(\u2022\u203F\u2022)",
            "(\u2299_\u2299)",
            "(\u2060\u25D5\u2060\u1D25\u2060\u25D5\u2060)",
            "\\(^o^)/",
            "(*^_^*)"
    };

    private final LatinIME mIme;
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private final SharedPreferences mPrefs;

    private final View mMenuPanel;
    private final View mEditPanel;
    private final View mEmojiPanel;
    private final ImageView mMenuButton;
    private final ListView mEmojiList;
    private final ImageView[] mTabs = new ImageView[CATEGORY_COUNT];
    private final View mTabStrip;
    private final ImageView mBarEmoji;
    private final TextView mBarKaomoji;

    private final int mIconColor;
    private final int mTabIconColor;

    private final int[] mSectionStart = new int[CATEGORY_COUNT];
    private int mSelectedTab = -1;
    private boolean mKaomojiMode;

    private final Runnable mRepeatDelete = new Runnable() {
        @Override
        public void run() {
            deleteOnce();
            mHandler.postDelayed(this, 50);
        }
    };

    ToolbarController(final LatinIME ime, final View root) {
        mIme = ime;
        mPrefs = ime.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        mIconColor = ime.getResources().getColor(R.color.pixel_toolbar_icon);
        mTabIconColor = ime.getResources().getColor(R.color.pixel_tab_icon);

        mMenuPanel = root.findViewById(R.id.pixel_menu_panel);
        mEditPanel = root.findViewById(R.id.pixel_edit_panel);
        mEmojiPanel = root.findViewById(R.id.pixel_emoji_panel);
        mMenuButton = (ImageView) root.findViewById(R.id.pixel_toolbar_menu);
        mEmojiList = (ListView) root.findViewById(R.id.pixel_emoji_list);
        mTabStrip = root.findViewById(R.id.pixel_emoji_tabs);
        mBarEmoji = (ImageView) root.findViewById(R.id.pixel_bar_emoji);
        mBarKaomoji = (TextView) root.findViewById(R.id.pixel_bar_kaomoji);

        // ---- toolbar
        click(root, R.id.pixel_toolbar_menu, new View.OnClickListener() {
            @Override public void onClick(final View v) { toggleMenu(); }
        });
        click(root, R.id.pixel_toolbar_settings, new View.OnClickListener() {
            @Override public void onClick(final View v) { closeMenus(); mIme.launchSettings(); }
        });
        click(root, R.id.pixel_toolbar_language, new View.OnClickListener() {
            @Override public void onClick(final View v) { closeMenus(); mIme.switchToNextSubtype(); }
        });
        click(root, R.id.pixel_toolbar_mic, new View.OnClickListener() {
            @Override public void onClick(final View v) { closeMenus(); mIme.startVoiceInput(); }
        });

        // ---- quick menu
        click(root, R.id.pixel_pill_undo, new View.OnClickListener() {
            @Override public void onClick(final View v) { closeMenus(); undo(); }
        });
        click(root, R.id.pixel_pill_clipboard, new View.OnClickListener() {
            @Override public void onClick(final View v) { closeMenus(); pasteFromClipboard(); }
        });
        click(root, R.id.pixel_pill_emoji, new View.OnClickListener() {
            @Override public void onClick(final View v) { showEmojiPanel(); }
        });
        click(root, R.id.pixel_pill_textedit, new View.OnClickListener() {
            @Override public void onClick(final View v) { showEditPanel(); }
        });
        click(root, R.id.pixel_pill_language, new View.OnClickListener() {
            @Override public void onClick(final View v) { closeMenus(); mIme.switchToNextSubtype(); }
        });
        click(root, R.id.pixel_pill_settings, new View.OnClickListener() {
            @Override public void onClick(final View v) { closeMenus(); mIme.launchSettings(); }
        });

        // ---- text editing
        key(root, R.id.pixel_edit_left, KeyEvent.KEYCODE_DPAD_LEFT);
        key(root, R.id.pixel_edit_up, KeyEvent.KEYCODE_DPAD_UP);
        key(root, R.id.pixel_edit_down, KeyEvent.KEYCODE_DPAD_DOWN);
        key(root, R.id.pixel_edit_right, KeyEvent.KEYCODE_DPAD_RIGHT);
        menuAction(root, R.id.pixel_edit_selectall, android.R.id.selectAll);
        menuAction(root, R.id.pixel_edit_copy, android.R.id.copy);
        menuAction(root, R.id.pixel_edit_cut, android.R.id.cut);
        menuAction(root, R.id.pixel_edit_paste, android.R.id.paste);

        // ---- emoji panel
        click(root, R.id.pixel_emoji_back, new View.OnClickListener() {
            @Override public void onClick(final View v) { hideAllPanels(); }
        });
        click(root, R.id.pixel_emoji_abc, new View.OnClickListener() {
            @Override public void onClick(final View v) { hideAllPanels(); }
        });
        click(root, R.id.pixel_bar_emoji, new View.OnClickListener() {
            @Override public void onClick(final View v) { setKaomojiMode(false); }
        });
        click(root, R.id.pixel_bar_kaomoji, new View.OnClickListener() {
            @Override public void onClick(final View v) { setKaomojiMode(true); }
        });
        final View delete = root.findViewById(R.id.pixel_emoji_delete);
        if (delete != null) {
            delete.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(final View v, final MotionEvent event) {
                    switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        deleteOnce();
                        mHandler.postDelayed(mRepeatDelete, 400);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        mHandler.removeCallbacks(mRepeatDelete);
                        return true;
                    default:
                        return true;
                    }
                }
            });
        }
        for (int i = 0; i < CATEGORY_COUNT; i++) {
            final int index = i;
            mTabs[i] = (ImageView) root.findViewById(TAB_IDS[i]);
            if (mTabs[i] != null) {
                mTabs[i].setColorFilter(mIconColor);
                mTabs[i].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(final View v) {
                        if (mKaomojiMode) {
                            setKaomojiMode(false);
                        }
                        selectTab(index);
                        mEmojiList.smoothScrollToPositionFromTop(mSectionStart[index], 0, 200);
                    }
                });
            }
        }
        if (mEmojiList != null) {
            mEmojiList.setOnScrollListener(new AbsListView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(final AbsListView view, final int scrollState) { }

                @Override
                public void onScroll(final AbsListView view, final int first, final int visible,
                        final int total) {
                    if (!mKaomojiMode) {
                        selectTab(sectionForRow(first));
                    }
                }
            });
        }
        updateBarModeVisuals();
    }

    // ------------------------------------------------------------------ panels

    void hideAllPanels() {
        mHandler.removeCallbacks(mRepeatDelete);
        setVisible(mMenuPanel, false);
        setVisible(mEditPanel, false);
        setVisible(mEmojiPanel, false);
        updateMenuIcon();
    }

    private void closeMenus() {
        setVisible(mMenuPanel, false);
        setVisible(mEditPanel, false);
        updateMenuIcon();
    }

    private void toggleMenu() {
        if (isVisible(mEmojiPanel)) {
            hideAllPanels();
        } else if (isVisible(mMenuPanel) || isVisible(mEditPanel)) {
            closeMenus();
        } else {
            setVisible(mMenuPanel, true);
            updateMenuIcon();
        }
    }

    private void showEditPanel() {
        setVisible(mMenuPanel, false);
        setVisible(mEditPanel, true);
        updateMenuIcon();
    }

    void showEmojiPanel() {
        closeMenus();
        setKaomojiMode(false);
        mSelectedTab = -1;
        selectTab(0);
        setVisible(mEmojiPanel, true);
        if (mEmojiList != null) {
            mEmojiList.setSelection(0);
        }
    }

    private void updateMenuIcon() {
        if (mMenuButton != null) {
            mMenuButton.setImageResource(isVisible(mMenuPanel) || isVisible(mEditPanel)
                    ? R.drawable.ic_pixel_close : R.drawable.ic_pixel_grid);
        }
    }

    private static boolean isVisible(final View v) {
        return v != null && v.getVisibility() == View.VISIBLE;
    }

    private static void setVisible(final View v, final boolean visible) {
        if (v != null) {
            v.setVisibility(visible ? View.VISIBLE : View.GONE);
        }
    }

    private static void click(final View root, final int id, final View.OnClickListener l) {
        final View v = root.findViewById(id);
        if (v != null) {
            v.setOnClickListener(l);
        }
    }

    private void key(final View root, final int id, final int keyCode) {
        click(root, id, new View.OnClickListener() {
            @Override public void onClick(final View v) { mIme.sendDownUpKeyEvents(keyCode); }
        });
    }

    private void menuAction(final View root, final int id, final int action) {
        click(root, id, new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                final InputConnection ic = mIme.getCurrentInputConnection();
                if (ic != null) {
                    ic.performContextMenuAction(action);
                }
            }
        });
    }

    // ------------------------------------------------------------------ actions

    private void undo() {
        final InputConnection ic = mIme.getCurrentInputConnection();
        if (ic == null) {
            return;
        }
        final long now = SystemClock.uptimeMillis();
        ic.sendKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_Z, 0,
                KeyEvent.META_CTRL_ON));
        ic.sendKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_Z, 0,
                KeyEvent.META_CTRL_ON));
    }

    private void pasteFromClipboard() {
        final ClipboardManager cm =
                (ClipboardManager) mIme.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip()) {
            return;
        }
        final ClipData clip = cm.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) {
            return;
        }
        final CharSequence text = clip.getItemAt(0).coerceToText(mIme);
        if (!TextUtils.isEmpty(text)) {
            mIme.onTextInput(text.toString());
        }
    }

    private void deleteOnce() {
        mIme.onEvent(LatinIME.createSoftwareKeypressEvent(Constants.CODE_DELETE,
                Constants.NOT_A_COORDINATE, Constants.NOT_A_COORDINATE, false));
    }

    // ------------------------------------------------------------------ emoji

    private static final class Row {
        final String header;
        final String[] cells;

        Row(final String header) {
            this.header = header;
            this.cells = null;
        }

        Row(final String[] cells) {
            this.header = null;
            this.cells = cells;
        }
    }

    private List<String> loadRecent() {
        final List<String> list = new ArrayList<String>();
        final String saved = mPrefs.getString(PREF_RECENT, "");
        if (!TextUtils.isEmpty(saved)) {
            for (final String s : saved.split(" ")) {
                if (!s.isEmpty()) {
                    list.add(s);
                }
            }
        }
        return list;
    }

    private void addRecent(final String emoji) {
        final List<String> list = loadRecent();
        list.remove(emoji);
        list.add(0, emoji);
        while (list.size() > MAX_RECENT) {
            list.remove(list.size() - 1);
        }
        mPrefs.edit().putString(PREF_RECENT, TextUtils.join(" ", list)).apply();
    }

    private static void addChunks(final List<Row> rows, final String[] items, final int cols) {
        for (int i = 0; i < items.length; i += cols) {
            final String[] chunk = new String[cols];
            for (int c = 0; c < cols; c++) {
                chunk[c] = i + c < items.length ? items[i + c] : "";
            }
            rows.add(new Row(chunk));
        }
    }

    private void rebuildList() {
        if (mEmojiList == null) {
            return;
        }
        final List<Row> rows = new ArrayList<Row>();
        if (mKaomojiMode) {
            addChunks(rows, KAOMOJI, KAOMOJI_COLUMNS);
            mEmojiList.setAdapter(new EmojiAdapter(rows, KAOMOJI_COLUMNS, true));
            return;
        }
        mSectionStart[0] = rows.size();
        rows.add(new Row(CATEGORY_TITLES[0]));
        final List<String> recent = loadRecent();
        if (recent.isEmpty()) {
            rows.add(new Row("Emoji you use will show up here"));
        } else {
            addChunks(rows, recent.toArray(new String[0]), EMOJI_COLUMNS);
        }
        for (int i = 1; i < CATEGORY_COUNT; i++) {
            mSectionStart[i] = rows.size();
            rows.add(new Row(CATEGORY_TITLES[i]));
            final String[] items = mIme.getResources().getString(CATEGORY_RES[i]).split(" ");
            addChunks(rows, items, EMOJI_COLUMNS);
        }
        mEmojiList.setAdapter(new EmojiAdapter(rows, EMOJI_COLUMNS, false));
    }

    private int sectionForRow(final int row) {
        for (int i = CATEGORY_COUNT - 1; i >= 0; i--) {
            if (row >= mSectionStart[i]) {
                return i;
            }
        }
        return 0;
    }

    private void selectTab(final int index) {
        if (index == mSelectedTab) {
            return;
        }
        mSelectedTab = index;
        for (int i = 0; i < CATEGORY_COUNT; i++) {
            final ImageView tab = mTabs[i];
            if (tab == null) {
                continue;
            }
            final boolean selected = i == index;
            tab.setBackgroundResource(selected ? R.drawable.bg_pixel_tab_circle : 0);
            tab.setColorFilter(selected ? mTabIconColor : mIconColor);
        }
    }

    private void setKaomojiMode(final boolean kaomoji) {
        mKaomojiMode = kaomoji;
        setVisible(mTabStrip, !kaomoji);
        updateBarModeVisuals();
        rebuildList();
        if (mEmojiList != null) {
            mEmojiList.setSelection(0);
        }
        if (!kaomoji) {
            mSelectedTab = -1;
            selectTab(0);
        }
    }

    private void updateBarModeVisuals() {
        if (mBarEmoji != null) {
            mBarEmoji.setBackgroundResource(mKaomojiMode ? 0 : R.drawable.bg_pixel_tab_pill);
            mBarEmoji.setColorFilter(mKaomojiMode ? mIconColor : mTabIconColor);
        }
        if (mBarKaomoji != null) {
            mBarKaomoji.setBackgroundResource(mKaomojiMode ? R.drawable.bg_pixel_tab_pill : 0);
            mBarKaomoji.setTextColor(mKaomojiMode ? mTabIconColor : mIconColor);
        }
    }

    private final View.OnClickListener mCellClick = new View.OnClickListener() {
        @Override
        public void onClick(final View v) {
            final Object tag = v.getTag();
            if (!(tag instanceof String) || ((String) tag).isEmpty()) {
                return;
            }
            final String text = (String) tag;
            mIme.onTextInput(text);
            if (!mKaomojiMode) {
                addRecent(text);
            }
        }
    };

    private int dp(final int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value,
                mIme.getResources().getDisplayMetrics());
    }

    private final class EmojiAdapter extends BaseAdapter {
        private final List<Row> mRows;
        private final int mColumns;
        private final boolean mSmallText;

        EmojiAdapter(final List<Row> rows, final int columns, final boolean smallText) {
            mRows = rows;
            mColumns = columns;
            mSmallText = smallText;
        }

        @Override
        public int getCount() {
            return mRows.size();
        }

        @Override
        public Object getItem(final int position) {
            return mRows.get(position);
        }

        @Override
        public long getItemId(final int position) {
            return position;
        }

        @Override
        public int getViewTypeCount() {
            return 2;
        }

        @Override
        public int getItemViewType(final int position) {
            return mRows.get(position).header != null ? 0 : 1;
        }

        @Override
        public boolean isEnabled(final int position) {
            return false;
        }

        @Override
        public View getView(final int position, final View convertView, final ViewGroup parent) {
            final Row row = mRows.get(position);
            if (row.header != null) {
                final TextView header;
                if (convertView instanceof TextView) {
                    header = (TextView) convertView;
                } else {
                    header = new TextView(mIme);
                    header.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
                    header.setTextColor(mIconColor);
                    header.setAlpha(0.75f);
                    header.setPadding(dp(10), dp(8), dp(10), dp(4));
                    header.setLayoutParams(new AbsListView.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT));
                }
                header.setText(row.header);
                return header;
            }
            final LinearLayout line;
            if (convertView instanceof LinearLayout) {
                line = (LinearLayout) convertView;
            } else {
                line = new LinearLayout(mIme);
                line.setOrientation(LinearLayout.HORIZONTAL);
                line.setLayoutParams(new AbsListView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
                for (int c = 0; c < mColumns; c++) {
                    final TextView cell = new TextView(mIme);
                    cell.setGravity(Gravity.CENTER);
                    cell.setSingleLine(true);
                    cell.setTextSize(TypedValue.COMPLEX_UNIT_SP, mSmallText ? 15 : 26);
                    cell.setTextColor(mIconColor);
                    cell.setLayoutParams(new LinearLayout.LayoutParams(0,
                            ViewGroup.LayoutParams.MATCH_PARENT, 1f));
                    cell.setOnClickListener(mCellClick);
                    line.addView(cell);
                }
            }
            for (int c = 0; c < mColumns; c++) {
                final TextView cell = (TextView) line.getChildAt(c);
                final String text = row.cells[c];
                cell.setText(text);
                cell.setTag(text);
            }
            return line;
        }
    }
}
