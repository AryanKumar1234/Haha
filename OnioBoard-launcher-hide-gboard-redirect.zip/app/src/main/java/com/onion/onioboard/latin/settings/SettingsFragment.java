/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.onion.onioboard.latin.settings;

import android.os.Bundle;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.preference.Preference;
import android.preference.SwitchPreference;
import android.preference.PreferenceScreen;

import com.onion.onioboard.R;
import com.onion.onioboard.latin.utils.ApplicationUtils;

public final class SettingsFragment extends InputMethodSettingsFragment {
    @Override
    public void onCreate(final Bundle icicle) {
        super.onCreate(icicle);
        setHasOptionsMenu(true);
        setInputMethodSettingsCategoryTitle(R.string.language_selection_title);
        setSubtypeEnablerTitle(R.string.select_language);
        addPreferencesFromResource(R.xml.prefs);

        final SwitchPreference hideLauncherPreference =
                (SwitchPreference) findPreference("pref_hide_from_launcher");
        if (hideLauncherPreference != null) {
            final ComponentName launcherComponent = new ComponentName(
                    getActivity(),
                    "com.onion.onioboard.latin.settings.Launcher");
            final PackageManager packageManager = getActivity().getPackageManager();

            // Read the actual component state so the switch stays correct after relaunch.
            final int componentState = packageManager.getComponentEnabledSetting(launcherComponent);
            final boolean isHidden = componentState == PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                    || componentState == PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER;
            hideLauncherPreference.setChecked(isHidden);
            hideLauncherPreference.setSummary(isHidden
                    ? "Enabled • OnioBoard is hidden from your app drawer"
                    : "Disabled • OnioBoard is visible in your app drawer");

            hideLauncherPreference.setOnPreferenceChangeListener(
                    new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    final boolean hide = (Boolean) newValue;
                    packageManager.setComponentEnabledSetting(
                            launcherComponent,
                            hide ? PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                                 : PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                            PackageManager.DONT_KILL_APP);
                    hideLauncherPreference.setSummary(hide
                            ? "Enabled • OnioBoard is hidden from your app drawer"
                            : "Disabled • OnioBoard is visible in your app drawer");
                    return true;
                }
            });
        }

        final SwitchPreference redirectPreference =
                (SwitchPreference) findPreference("pref_redirect_to_gboard");
        if (redirectPreference != null) {
            redirectPreference.setSummary(redirectPreference.isChecked()
                    ? "Enabled • Opening OnioBoard launches Gboard"
                    : "Disabled • Opening OnioBoard opens OnioBoard");
            redirectPreference.setOnPreferenceChangeListener(
                    new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    final boolean enabled = (Boolean) newValue;
                    redirectPreference.setSummary(enabled
                            ? "Enabled • Opening OnioBoard launches Gboard"
                            : "Disabled • Opening OnioBoard opens OnioBoard");
                    return true;
                }
            });
        }

        final PreferenceScreen preferenceScreen = getPreferenceScreen();
        preferenceScreen.setTitle(
                ApplicationUtils.getActivityTitleResId(getActivity(), SettingsActivity.class));
    }
}
