package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface asl {
    void a(Object obj);
}
