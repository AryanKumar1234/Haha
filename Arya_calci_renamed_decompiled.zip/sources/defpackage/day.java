package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class day {
    public static final day a = new day();
}
