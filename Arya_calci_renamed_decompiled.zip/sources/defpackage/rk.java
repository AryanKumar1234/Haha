package defpackage;

import android.view.animation.Interpolator;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class rk implements Interpolator {
    public abstract float a();
}
