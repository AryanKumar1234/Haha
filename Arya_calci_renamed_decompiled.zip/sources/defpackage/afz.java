package defpackage;

import android.widget.CompoundButton;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class afz implements CompoundButton.OnCheckedChangeListener {
    public static final /* synthetic */ int a = 0;

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        throw null;
    }
}
