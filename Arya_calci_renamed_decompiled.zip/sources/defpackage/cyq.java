package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface cyq {
    boolean a();

    boolean b();

    void c();
}
