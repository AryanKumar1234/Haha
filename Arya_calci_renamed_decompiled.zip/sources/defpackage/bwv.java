package defpackage;

import android.R;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class bwv {
    public static final int[] a = {R.attr.background, R.attr.checked, R.attr.insetLeft, R.attr.insetRight, R.attr.insetTop, R.attr.insetBottom, R.attr.checkable, com.google.android.calculator.R.attr.backgroundTint, com.google.android.calculator.R.attr.backgroundTintMode, com.google.android.calculator.R.attr.cornerRadius, com.google.android.calculator.R.attr.elevation, com.google.android.calculator.R.attr.icon, com.google.android.calculator.R.attr.iconGravity, com.google.android.calculator.R.attr.iconPadding, com.google.android.calculator.R.attr.iconSize, com.google.android.calculator.R.attr.iconTint, com.google.android.calculator.R.attr.iconTintMode, com.google.android.calculator.R.attr.opticalCenterEnabled, com.google.android.calculator.R.attr.rippleColor, com.google.android.calculator.R.attr.secondaryIcon, com.google.android.calculator.R.attr.secondaryIconGravity, com.google.android.calculator.R.attr.secondaryIconTint, com.google.android.calculator.R.attr.secondaryIconTintMode, com.google.android.calculator.R.attr.shapeAppearance, com.google.android.calculator.R.attr.shapeAppearanceOverlay, com.google.android.calculator.R.attr.strokeColor, com.google.android.calculator.R.attr.strokeWidth, com.google.android.calculator.R.attr.toggleCheckedStateOnClick};
}
