package defpackage;

import android.content.AttributionSource;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class avm {
    public final AttributionSource a;

    public avm(AttributionSource attributionSource) {
        this.a = attributionSource;
    }
}
