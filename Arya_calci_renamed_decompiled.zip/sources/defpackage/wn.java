package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class wn extends RuntimeException {
}
