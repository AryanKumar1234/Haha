package defpackage;

import java.io.IOException;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class btw extends IOException {
    public btw(String str) {
        super(str);
    }

    public btw(Throwable th) {
        super(th);
    }
}
