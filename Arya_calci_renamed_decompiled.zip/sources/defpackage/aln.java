package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aln extends ArithmeticException {
    public aln() {
        super("Division by zero");
    }
}
