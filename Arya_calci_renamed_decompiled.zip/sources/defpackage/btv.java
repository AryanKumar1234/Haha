package defpackage;

import java.io.IOException;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class btv extends IOException {
    public btv(String str) {
        super(str);
    }
}
