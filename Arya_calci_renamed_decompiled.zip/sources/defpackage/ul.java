package defpackage;

import java.util.List;

/* compiled from: PG */
/* loaded from: classes2.dex */
interface ul extends Cloneable {
    ul d();

    Class e();

    Object f(float f);

    List g();

    void h(uz uzVar);
}
