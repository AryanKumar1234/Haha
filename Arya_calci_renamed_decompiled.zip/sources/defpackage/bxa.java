package defpackage;

import android.R;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class bxa {
    public static final int[] a = {R.attr.button, com.google.android.calculator.R.attr.buttonCompat, com.google.android.calculator.R.attr.buttonIcon, com.google.android.calculator.R.attr.buttonIconTint, com.google.android.calculator.R.attr.buttonIconTintMode, com.google.android.calculator.R.attr.buttonTint, com.google.android.calculator.R.attr.centerIfNoTextEnabled, com.google.android.calculator.R.attr.checkedState, com.google.android.calculator.R.attr.errorAccessibilityLabel, com.google.android.calculator.R.attr.errorShown, com.google.android.calculator.R.attr.rippleColor, com.google.android.calculator.R.attr.useMaterialThemeColors};
}
