package defpackage;

/* compiled from: PG */
@FunctionalInterface
/* loaded from: classes2.dex */
public interface bbu {
}
