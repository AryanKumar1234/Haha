package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class ayv extends IllegalStateException {
    public ayv(String str, Throwable th) {
        super(str, th);
    }
}
