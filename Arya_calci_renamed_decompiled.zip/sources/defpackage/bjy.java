package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class bjy {
    public abstract void k();
}
