package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class avk {
    public static String a;
    public static Boolean b;
}
