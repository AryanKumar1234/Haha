package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class bsu {
    public static final bsu a;
    public static final bsu b;
    public static final bsu c;
    public static final bsu d;
    public static final bsu e;
    public static final bsu f;
    public static final bsu g;
    public static final bsu h;
    public static final bsu i;
    public static final bsu j;
    private static final /* synthetic */ bsu[] k;

    static {
        bsu bsuVar = new bsu("ASYNC_TASK", 0);
        a = bsuVar;
        bsu bsuVar2 = new bsu("UNCAUGHT_EXCEPTION_HANDLER", 1);
        b = bsuVar2;
        bsu bsuVar3 = new bsu("PRIMES", 2);
        c = bsuVar3;
        bsu bsuVar4 = new bsu("APP_DOCTOR", 3);
        d = bsuVar4;
        bsu bsuVar5 = new bsu("JVM_LOG_FORMAT", 4);
        e = bsuVar5;
        bsu bsuVar6 = new bsu("LOGGING", 5);
        f = bsuVar6;
        bsu bsuVar7 = new bsu("STRICT_MODE", 6);
        g = bsuVar7;
        bsu bsuVar8 = new bsu("SSLGUARD", 7);
        h = bsuVar8;
        bsu bsuVar9 = new bsu("CRONET_URLSTREAMHANDLER", 8);
        i = bsuVar9;
        bsu bsuVar10 = new bsu("STARTUP_LISTENERS", 9);
        j = bsuVar10;
        k = new bsu[]{bsuVar, bsuVar2, bsuVar3, bsuVar4, bsuVar5, bsuVar6, bsuVar7, bsuVar8, bsuVar9, bsuVar10};
    }

    public static bsu[] values() {
        return (bsu[]) k.clone();
    }
}
