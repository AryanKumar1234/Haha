package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aks {
    public int a;
    public int b;
    public int c;
    public int d;
    public int e;
    public int f;

    public final void a(aks aksVar) {
        this.a += aksVar.a;
        this.b += aksVar.b;
        this.c += aksVar.c;
        this.d += aksVar.d;
        this.e += aksVar.e;
        this.f += aksVar.f;
    }
}
