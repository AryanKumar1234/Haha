package defpackage;

import com.google.android.calculator.R;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class byv {
    public static final int[] a = {R.attr.buttonTint, R.attr.rippleColor, R.attr.useMaterialThemeColors};
}
