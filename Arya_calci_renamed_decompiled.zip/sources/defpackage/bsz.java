package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface bsz {
    coi a();
}
