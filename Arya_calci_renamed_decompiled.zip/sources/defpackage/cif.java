package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public enum cif {
    GENERAL(true),
    BOOLEAN(false),
    CHARACTER(false),
    INTEGRAL(false),
    FLOAT(true);

    public final boolean f;

    cif(boolean z) {
        this.f = z;
    }
}
