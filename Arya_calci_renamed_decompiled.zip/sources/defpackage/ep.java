package defpackage;

import android.widget.ListView;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface ep {
    ListView bA();

    void k();

    void s();

    boolean u();
}
