package defpackage;

import java.util.concurrent.atomic.AtomicReference;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aod {
    public static final AtomicReference a = new AtomicReference();
}
