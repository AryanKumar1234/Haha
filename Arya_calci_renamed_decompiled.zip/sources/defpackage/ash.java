package defpackage;

import android.content.Intent;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface ash {
    void Y(Intent intent, int i);
}
