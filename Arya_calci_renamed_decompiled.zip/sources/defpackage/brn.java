package defpackage;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface brn extends cda {
    @Override // defpackage.cda
    Object cd();

    Object ce(Context context);
}
