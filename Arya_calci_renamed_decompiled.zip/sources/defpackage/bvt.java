package defpackage;

import android.view.View;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class bvt {
    public final View a;
    public int b;
    public int c;

    public bvt(View view) {
        this.a = view;
    }
}
