package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class mx {
    public static final long[] a = new long[0];
}
