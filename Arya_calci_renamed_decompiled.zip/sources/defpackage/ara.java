package defpackage;

import java.util.Collections;
import java.util.WeakHashMap;

/* compiled from: PG */
@Deprecated
/* loaded from: classes2.dex */
public class ara {
    static {
        Collections.newSetFromMap(new WeakHashMap());
    }
}
