package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface azv {
    void a();
}
