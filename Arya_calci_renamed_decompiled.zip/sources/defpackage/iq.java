package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class iq {
    public int a;
    public int b;
    public boolean c;
    public boolean d;
}
