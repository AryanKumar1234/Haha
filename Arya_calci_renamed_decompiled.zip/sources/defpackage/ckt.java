package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface ckt {
    StackTraceElement a(Class cls);

    StackTraceElement[] b(Class cls, int i);
}
