package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class ba {
    public static final /* synthetic */ int a = 0;

    static {
        try {
            Class<?> cls = Class.forName("agi");
            cls.getClass();
        } catch (Exception unused) {
        }
    }
}
