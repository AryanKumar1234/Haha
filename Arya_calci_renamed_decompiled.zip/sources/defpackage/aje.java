package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aje {
    void a();

    boolean b();
}
