package defpackage;

import java.util.concurrent.Executor;
import java.util.concurrent.Future;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface coi extends Future {
    void m(Runnable runnable, Executor executor);
}
