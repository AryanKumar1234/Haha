package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface nz {
    float a(float f);

    float b();

    boolean c();
}
