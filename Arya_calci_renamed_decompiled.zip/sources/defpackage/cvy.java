package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class cvy {
    public static final cvy a = new cvy();

    private cvy() {
    }
}
