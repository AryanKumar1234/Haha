package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface bbf {
    Iterable a();

    String b();

    String c();

    void d();
}
