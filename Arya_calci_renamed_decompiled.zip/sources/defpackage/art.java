package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class art extends ThreadLocal {
    @Override // java.lang.ThreadLocal
    protected final /* bridge */ /* synthetic */ Object initialValue() {
        return false;
    }
}
