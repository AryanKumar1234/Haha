package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class cu {
    boolean a;
    long b;
}
