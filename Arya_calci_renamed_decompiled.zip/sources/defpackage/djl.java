package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class djl extends Exception {
    static {
        new djl();
    }

    private djl() {
    }
}
