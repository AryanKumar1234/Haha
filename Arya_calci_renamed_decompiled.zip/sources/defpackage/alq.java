package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class alq extends ArithmeticException {
    public alq(String str) {
        super(str);
    }
}
