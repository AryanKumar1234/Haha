package defpackage;

import android.util.SparseIntArray;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class sq {
    public static final SparseIntArray a;
    public boolean b = false;
    public float c = 0.0f;
    public float d = 0.0f;
    public float e = 0.0f;
    public float f = 1.0f;
    public float g = 1.0f;
    public float h = Float.NaN;
    public float i = Float.NaN;
    public int j = -1;
    public float k = 0.0f;
    public float l = 0.0f;
    public float m = 0.0f;
    public boolean n = false;
    public float o = 0.0f;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        a = sparseIntArray;
        int[] iArr = sv.a;
        sparseIntArray.append(6, 1);
        sparseIntArray.append(7, 2);
        sparseIntArray.append(8, 3);
        sparseIntArray.append(4, 4);
        sparseIntArray.append(5, 5);
        sparseIntArray.append(0, 6);
        sparseIntArray.append(1, 7);
        sparseIntArray.append(2, 8);
        sparseIntArray.append(3, 9);
        sparseIntArray.append(9, 10);
        sparseIntArray.append(10, 11);
        sparseIntArray.append(11, 12);
    }

    public final void a(sq sqVar) {
        this.b = sqVar.b;
        this.c = sqVar.c;
        this.d = sqVar.d;
        this.e = sqVar.e;
        this.f = sqVar.f;
        this.g = sqVar.g;
        this.h = sqVar.h;
        this.i = sqVar.i;
        this.j = sqVar.j;
        this.k = sqVar.k;
        this.l = sqVar.l;
        this.m = sqVar.m;
        this.n = sqVar.n;
        this.o = sqVar.o;
    }
}
