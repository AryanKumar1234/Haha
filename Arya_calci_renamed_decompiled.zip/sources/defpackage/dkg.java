package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class dkg {
    public final String a;

    public dkg(String str) {
        this.a = str;
    }

    public final String toString() {
        return "<" + this.a + ">";
    }
}
