package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class bvd {
    public static final bvd a = new bvd();
}
