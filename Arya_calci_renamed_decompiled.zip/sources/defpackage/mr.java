package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class mr {
    public static final Object a = new Object();
}
