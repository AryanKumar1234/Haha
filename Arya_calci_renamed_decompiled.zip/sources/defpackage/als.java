package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class als extends ArithmeticException {
    public als(String str) {
        super(str);
    }
}
