package defpackage;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface czi {
    boolean a(Context context);

    boolean b(Context context);

    boolean c(Context context);

    boolean d(Context context);
}
