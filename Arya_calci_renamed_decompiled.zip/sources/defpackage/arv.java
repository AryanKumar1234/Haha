package defpackage;

import android.os.Bundle;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface arv {
    void a(Bundle bundle);

    void b(int i);
}
