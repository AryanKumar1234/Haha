package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class vs {
    public final int a;
    public final boolean b;
    public final String c;
    public final int d;
    public final int e;

    public vs(int i, boolean z, String str, int i2, int i3) {
        this.a = i;
        this.b = z;
        this.c = str;
        this.d = i2;
        this.e = i3;
    }
}
