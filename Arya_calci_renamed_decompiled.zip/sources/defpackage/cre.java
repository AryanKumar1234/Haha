package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface cre {
    boolean a(int i);
}
