package defpackage;

import android.view.ViewGroup;
import android.widget.LinearLayout;

/* compiled from: PG */
/* loaded from: classes2.dex */
public class ht extends LinearLayout.LayoutParams {
    public ht(int i) {
        super(i, -2);
    }

    public ht(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
    }
}
