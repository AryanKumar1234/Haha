package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class dhf {
    public static final dkg a = new dkg("CLOSED_EMPTY");
}
