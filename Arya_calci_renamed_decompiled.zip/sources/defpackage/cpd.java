package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class cpd {
    protected cpd() {
    }

    public abstract Throwable l();
}
