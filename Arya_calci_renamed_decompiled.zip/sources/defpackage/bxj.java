package defpackage;

import com.google.android.calculator.R;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class bxj {
    public static final int[] a = {R.attr.dividerColor, R.attr.dividerInsetEnd, R.attr.dividerInsetStart, R.attr.dividerThickness, R.attr.lastItemDecorated};
}
