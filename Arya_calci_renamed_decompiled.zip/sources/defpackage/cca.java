package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public enum cca {
    CLAIMED(true),
    SKIPPED(false);

    public final boolean c;

    cca(boolean z) {
        this.c = z;
    }
}
