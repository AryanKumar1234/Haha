package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class bez extends Exception {
}
