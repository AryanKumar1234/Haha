package defpackage;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface czr {
    boolean a(Context context);

    boolean b(Context context);
}
