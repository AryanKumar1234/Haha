package defpackage;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class ea$$ExternalSyntheticApiModelOutline0 {
}
