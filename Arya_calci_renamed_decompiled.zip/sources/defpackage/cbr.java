package defpackage;

import java.io.Closeable;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface cbr extends Closeable {
    @Override // java.io.Closeable, java.lang.AutoCloseable
    void close();
}
