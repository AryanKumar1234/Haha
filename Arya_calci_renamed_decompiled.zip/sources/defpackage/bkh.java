package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
interface bkh {
    void a();
}
