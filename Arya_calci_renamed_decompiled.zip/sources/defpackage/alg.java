package defpackage;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class alg implements ake {
    @Override // defpackage.ake
    public final float d() {
        return 0.0f;
    }

    @Override // defpackage.ake
    public final float e() {
        return 0.0f;
    }

    @Override // defpackage.ake
    public final float m(String str, int i) {
        return 0.0f;
    }

    @Override // defpackage.ake
    public final int o() {
        return 19;
    }
}
