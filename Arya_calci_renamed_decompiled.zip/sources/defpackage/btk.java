package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class btk extends RuntimeException {
    public btk(String str) {
        super(str);
    }
}
