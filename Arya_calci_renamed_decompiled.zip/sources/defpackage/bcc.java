package defpackage;

import android.os.StrictMode$OnThreadViolationListener;
import android.os.strictmode.Violation;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class bcc implements StrictMode$OnThreadViolationListener {
    public final void onThreadViolation(Violation violation) {
    }
}
