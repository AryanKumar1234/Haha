package defpackage;

import android.view.ViewDebug;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class fi extends ht {

    @ViewDebug.ExportedProperty
    public boolean a;

    @ViewDebug.ExportedProperty
    public int b;

    @ViewDebug.ExportedProperty
    public int c;

    @ViewDebug.ExportedProperty
    public boolean d;

    @ViewDebug.ExportedProperty
    public boolean e;
    public boolean f;

    public fi() {
        super(-2);
        this.a = false;
    }

    public fi(fi fiVar) {
        super(fiVar);
        this.a = fiVar.a;
    }
}
