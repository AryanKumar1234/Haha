package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface ass {
    void a(Object obj, Object obj2);
}
