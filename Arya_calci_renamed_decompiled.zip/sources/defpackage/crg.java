package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface crg {
    Object a(int i);
}
