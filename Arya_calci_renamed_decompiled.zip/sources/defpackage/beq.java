package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class beq {
    public final bek a;

    public beq(bek bekVar) {
        this.a = bekVar;
    }

    public final String toString() {
        return this.a.toString();
    }
}
