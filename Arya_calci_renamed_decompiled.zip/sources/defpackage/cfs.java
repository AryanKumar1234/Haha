package defpackage;

import java.util.Set;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface cfs {
    Set a();
}
