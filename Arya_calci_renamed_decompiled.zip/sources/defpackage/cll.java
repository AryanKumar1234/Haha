package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class cll {
    Object a;
    int b;

    public cll(Object obj, int i) {
        this.a = obj;
        this.b = i;
    }

    public final String toString() {
        return "countOrWorkerId[" + this.b + "][" + String.valueOf(this.a) + "]";
    }
}
