package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class dba {
    public static final dba a = new dba();

    private dba() {
    }

    public final String toString() {
        return "kotlin.Unit";
    }
}
