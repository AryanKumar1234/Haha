package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface bly {
    void a(int i, String str);
}
