package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface cxl extends cxi {
}
