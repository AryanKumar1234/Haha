package defpackage;

import com.google.android.calculator.R;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class bvr {
    public static final int[] a = {R.attr.logoAdjustViewBounds, R.attr.logoScaleType, R.attr.navigationIconTint, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.subtitleCentered, R.attr.titleCentered};
    public static final int[] b = {R.attr.behavior_overlapTop};
}
