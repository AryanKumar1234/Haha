package defpackage;

import android.R;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class bwp {
    public static final int[] a = {R.attr.maxWidth, R.attr.maxHeight, R.attr.elevation, com.google.android.calculator.R.attr.backgroundTint, com.google.android.calculator.R.attr.behavior_autoExpandOnRequestChildRectangleOffscreen, com.google.android.calculator.R.attr.behavior_draggable, com.google.android.calculator.R.attr.behavior_draggableOnNestedScroll, com.google.android.calculator.R.attr.behavior_expandedOffset, com.google.android.calculator.R.attr.behavior_fitToContents, com.google.android.calculator.R.attr.behavior_halfExpandedRatio, com.google.android.calculator.R.attr.behavior_hideable, com.google.android.calculator.R.attr.behavior_multipleScrollingChildrenSupported, com.google.android.calculator.R.attr.behavior_peekHeight, com.google.android.calculator.R.attr.behavior_saveFlags, com.google.android.calculator.R.attr.behavior_significantVelocityThreshold, com.google.android.calculator.R.attr.behavior_skipCollapsed, com.google.android.calculator.R.attr.gestureInsetBottomIgnored, com.google.android.calculator.R.attr.marginLeftSystemWindowInsets, com.google.android.calculator.R.attr.marginRightSystemWindowInsets, com.google.android.calculator.R.attr.marginTopSystemWindowInsets, com.google.android.calculator.R.attr.paddingBottomSystemWindowInsets, com.google.android.calculator.R.attr.paddingLeftSystemWindowInsets, com.google.android.calculator.R.attr.paddingRightSystemWindowInsets, com.google.android.calculator.R.attr.paddingTopSystemWindowInsets, com.google.android.calculator.R.attr.shapeAppearance, com.google.android.calculator.R.attr.shapeAppearanceOverlay, com.google.android.calculator.R.attr.shouldRemoveExpandedCorners};
}
