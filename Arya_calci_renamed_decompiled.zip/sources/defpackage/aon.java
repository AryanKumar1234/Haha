package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public enum aon {
    ZWIEBACK(2),
    ANDROID_ID(4),
    GAIA(8),
    ACCOUNT_NAME(16);

    public final int e;

    aon(int i) {
        this.e = i;
    }
}
