package defpackage;

import android.graphics.Matrix;

/* compiled from: PG */
/* loaded from: classes2.dex */
class bzt {
    static {
        new Matrix();
    }

    public bzt() {
        new Matrix();
    }

    public bzt(char[] cArr) {
        this();
    }

    public bzt(byte[] bArr) {
        this();
    }
}
