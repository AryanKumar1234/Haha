package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface ckz {
    void b(byte[] bArr);
}
