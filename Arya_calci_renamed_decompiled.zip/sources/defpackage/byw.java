package defpackage;

import android.content.res.ColorStateList;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class byw {
    private byw() {
    }

    public static ColorStateList a(ColorStateList colorStateList) {
        return colorStateList != null ? colorStateList : ColorStateList.valueOf(0);
    }
}
