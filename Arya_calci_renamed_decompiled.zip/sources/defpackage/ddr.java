package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface ddr extends daq {
    Object a(Object obj);
}
