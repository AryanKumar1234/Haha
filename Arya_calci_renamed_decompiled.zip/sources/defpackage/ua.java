package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class ua implements uz {
    private final /* synthetic */ int d;
    public static final ua c = new ua(2);
    public static final ua b = new ua(1);
    public static final ua a = new ua(0);

    private ua(int i) {
        this.d = i;
    }

    @Override // defpackage.uz
    public final /* synthetic */ Object a(float f, Object obj, Object obj2) {
        int i = this.d;
        if (i == 0) {
            float floatValue = ((Float) obj).floatValue();
            return Float.valueOf(floatValue + (f * (((Float) obj2).floatValue() - floatValue)));
        }
        if (i != 1) {
            return Integer.valueOf((int) (((Integer) obj).intValue() + (f * (((Integer) obj2).intValue() - r10))));
        }
        int intValue = ((Integer) obj).intValue() >> 24;
        int intValue2 = ((Integer) obj2).intValue() >> 24;
        float pow = (float) Math.pow(((r10 >> 16) & 255) / 255.0f, 2.2d);
        float pow2 = (float) Math.pow(((r10 >> 8) & 255) / 255.0f, 2.2d);
        float pow3 = (float) Math.pow((r10 & 255) / 255.0f, 2.2d);
        float pow4 = (float) Math.pow(((r13 >> 16) & 255) / 255.0f, 2.2d);
        float pow5 = (float) Math.pow(((r13 >> 8) & 255) / 255.0f, 2.2d);
        float pow6 = (float) Math.pow((r13 & 255) / 255.0f, 2.2d);
        float pow7 = (float) Math.pow(pow + ((pow4 - pow) * f), 0.45454545454545453d);
        float pow8 = (float) Math.pow(pow2 + ((pow5 - pow2) * f), 0.45454545454545453d);
        float f2 = (intValue & 255) / 255.0f;
        return Integer.valueOf(Math.round(((float) Math.pow(pow3 + ((pow6 - pow3) * f), 0.45454545454545453d)) * 255.0f) | (Math.round((f2 + (f * (((intValue2 & 255) / 255.0f) - f2))) * 255.0f) << 24) | (Math.round(pow7 * 255.0f) << 16) | (Math.round(pow8 * 255.0f) << 8));
    }
}
