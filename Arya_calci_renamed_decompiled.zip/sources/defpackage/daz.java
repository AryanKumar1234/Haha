package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class daz extends RuntimeException {
    public daz(String str) {
        super(str);
    }
}
