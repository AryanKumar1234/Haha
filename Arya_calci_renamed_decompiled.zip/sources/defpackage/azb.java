package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class azb extends RuntimeException {
    public azb(Throwable th) {
        super(th);
    }
}
