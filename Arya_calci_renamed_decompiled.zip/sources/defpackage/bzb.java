package defpackage;

import android.graphics.RectF;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface bzb {
    float a(RectF rectF);
}
