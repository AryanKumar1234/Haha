package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface ake {
    float d();

    float e();

    float m(String str, int i);

    int o();
}
