package defpackage;

import java.io.File;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface btu {
    File a();
}
