package defpackage;

import android.accounts.Account;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class btq {
    public static final Account a = new Account("shared", "mobstore");

    public static boolean a(Account account) {
        return a.equals(account);
    }
}
