package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class cmc {
    static final cmc a = new cmc(new cmb());
    final Throwable b;

    public cmc(Throwable th) {
        th.getClass();
        this.b = th;
    }
}
