package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class me {
    public abstract void b(mb mbVar);
}
