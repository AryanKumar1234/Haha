package defpackage;

import android.text.Spannable;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class alw {
    public final boolean a = true;
    public Spannable b;
    public long c;
    public long d;

    public alw(long j, long j2, Spannable spannable) {
        this.c = j;
        this.d = j2;
        this.b = spannable;
    }

    public alw() {
    }
}
