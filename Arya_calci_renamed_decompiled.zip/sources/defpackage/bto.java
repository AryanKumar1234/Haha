package defpackage;

import android.net.Uri;
import java.util.List;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class bto {
    public buh a;
    public List b;
    public List c;
    public Uri d;
}
