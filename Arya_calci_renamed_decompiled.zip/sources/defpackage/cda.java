package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface cda {
    Object cd();

    boolean equals(Object obj);
}
