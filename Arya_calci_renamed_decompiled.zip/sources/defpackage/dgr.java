package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class dgr extends Error {
    public dgr(String str, Throwable th) {
        super(str, th);
    }
}
