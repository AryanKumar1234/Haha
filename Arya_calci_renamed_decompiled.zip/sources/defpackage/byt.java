package defpackage;

import com.google.android.calculator.R;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class byt {
    public static final int[] a = {R.attr.damping, R.attr.stiffness};
}
