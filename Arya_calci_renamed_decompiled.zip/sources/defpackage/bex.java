package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class bex {
    public Object a;

    public bex(are areVar) {
        this.a = areVar;
    }

    public bex() {
    }
}
