package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class dkr implements Runnable {
    public long g;
    public boolean h;

    public dkr(long j, boolean z) {
        this.g = j;
        this.h = z;
    }

    public dkr() {
        this(0L, false);
    }
}
