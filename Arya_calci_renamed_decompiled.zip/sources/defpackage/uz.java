package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface uz {
    Object a(float f, Object obj, Object obj2);
}
