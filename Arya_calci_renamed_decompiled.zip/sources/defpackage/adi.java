package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface adi extends ads {
    void a();

    void b();
}
