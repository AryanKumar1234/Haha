package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface bgu extends Comparable {
    long a();

    Object b();
}
