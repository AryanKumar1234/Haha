package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class cce extends Exception {
    public cce() {
    }

    public cce(String str, Throwable th) {
        super(str, th);
    }
}
