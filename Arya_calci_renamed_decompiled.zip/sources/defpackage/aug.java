package defpackage;

import android.os.IInterface;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aug extends IInterface {
    int c();

    avq d();
}
