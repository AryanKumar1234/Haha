package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface ahz {
    void a();

    void b(boolean z);

    void c(boolean z);

    void d(int i);

    void e(int i);

    void f(int i);

    void g();

    void h();

    void i();

    void j();

    void k();

    void l(int i);

    void m();

    void n();

    void o();

    void p(int i);

    void q(int i);

    void r(int i, int i2);
}
