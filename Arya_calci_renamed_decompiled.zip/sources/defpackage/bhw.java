package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface bhw {
    int a();

    boolean b();

    void c();
}
