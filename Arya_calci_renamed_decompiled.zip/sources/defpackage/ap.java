package defpackage;

import java.util.ArrayList;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: PG */
/* loaded from: classes2.dex */
public interface ap {
    boolean e(ArrayList arrayList, ArrayList arrayList2);
}
