package defpackage;

import java.io.Serializable;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class dar implements Serializable, das {
    private final Object a;

    public dar(Object obj) {
        this.a = obj;
    }

    @Override // defpackage.das
    public final Object a() {
        throw null;
    }

    public final String toString() {
        return String.valueOf(this.a);
    }
}
