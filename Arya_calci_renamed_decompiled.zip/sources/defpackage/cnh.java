package defpackage;

import java.util.concurrent.Executor;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: PG */
/* loaded from: classes2.dex */
public final class cnh implements Executor {
    public static final cnh a;
    private static final /* synthetic */ cnh[] b;

    static {
        cnh cnhVar = new cnh();
        a = cnhVar;
        b = new cnh[]{cnhVar};
    }

    private cnh() {
    }

    public static cnh[] values() {
        return (cnh[]) b.clone();
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        runnable.run();
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "MoreExecutors.directExecutor()";
    }
}
