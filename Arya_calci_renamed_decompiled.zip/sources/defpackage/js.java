package defpackage;

import android.content.res.Resources;
import android.widget.SpinnerAdapter;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface js extends SpinnerAdapter {
    Resources.Theme a();

    void b();
}
