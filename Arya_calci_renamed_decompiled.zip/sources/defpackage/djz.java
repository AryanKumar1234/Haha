package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class djz {
    public final int a;

    public djz(int i) {
        this.a = i;
    }
}
