package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class cdh extends RuntimeException {
    public cdh(String str) {
        super(str);
    }
}
