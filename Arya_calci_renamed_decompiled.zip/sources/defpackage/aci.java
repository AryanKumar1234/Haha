package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class aci {
    public abstract float a(Object obj);

    public abstract void b(Object obj, float f);
}
