package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aud {
    public final String a;
    public final String b = "com.google.android.gms";
    public final int c = 4225;
    public final boolean d;

    public aud(String str, boolean z) {
        this.a = str;
        this.d = z;
    }
}
