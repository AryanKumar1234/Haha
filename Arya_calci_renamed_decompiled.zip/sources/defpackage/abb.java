package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class abb extends abc {
    @Override // defpackage.abc
    public final void a() {
        throw null;
    }

    @Override // defpackage.abc
    public final void b() {
        throw null;
    }
}
