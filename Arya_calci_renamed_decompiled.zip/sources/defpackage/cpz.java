package defpackage;

import java.util.Iterator;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface cpz extends Iterator {
    byte a();
}
