package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class dmz extends bek {
    public dmz() {
        super(2065731759);
    }

    @Override // defpackage.bek
    public final void a() {
    }
}
