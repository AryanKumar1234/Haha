package defpackage;

import android.os.Parcelable;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aux extends Parcelable {
    public static final String NULL = "SAFE_PARCELABLE_NULL_STRING";
}
