package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface bpj {
    Object a();
}
