package defpackage;

import android.content.Context;
import android.content.res.Resources;
import com.google.android.calculator.R;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Locale;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class ait {
    public static HashMap a;
    public static int b;
    public static Context c;
    private static String d;
    private static HashMap e;
    private static Locale f;

    public static byte a(int i) {
        if (i == R.id.const_pi) {
            return (byte) 112;
        }
        if (i == R.id.const_e) {
            return (byte) 101;
        }
        if (i == R.id.op_sqrt) {
            return (byte) 114;
        }
        if (i == R.id.op_fact) {
            return (byte) 33;
        }
        if (i == R.id.op_pct) {
            return (byte) 37;
        }
        if (i == R.id.fun_sin) {
            return (byte) 115;
        }
        if (i == R.id.fun_cos) {
            return (byte) 99;
        }
        if (i == R.id.fun_tan) {
            return (byte) 116;
        }
        if (i == R.id.fun_arcsin) {
            return (byte) 83;
        }
        if (i == R.id.fun_arccos) {
            return (byte) 67;
        }
        if (i == R.id.fun_arctan) {
            return (byte) 84;
        }
        if (i == R.id.fun_ln) {
            return (byte) 108;
        }
        if (i == R.id.fun_log) {
            return (byte) 76;
        }
        if (i == R.id.fun_exp) {
            return (byte) 69;
        }
        if (i == R.id.lparen) {
            return (byte) 40;
        }
        if (i == R.id.rparen) {
            return (byte) 41;
        }
        if (i == R.id.op_pow) {
            return (byte) 94;
        }
        if (i == R.id.op_mul) {
            return (byte) 42;
        }
        if (i == R.id.op_div) {
            return (byte) 47;
        }
        if (i == R.id.op_add) {
            return (byte) 43;
        }
        if (i == R.id.op_sub) {
            return (byte) 45;
        }
        if (i == R.id.op_sqr) {
            return (byte) 50;
        }
        throw new AssertionError("Unexpected key id");
    }

    public static int b(int i) {
        if (i == R.id.digit_0) {
            return 0;
        }
        if (i == R.id.digit_1) {
            return 1;
        }
        if (i == R.id.digit_2) {
            return 2;
        }
        if (i == R.id.digit_3) {
            return 3;
        }
        if (i == R.id.digit_4) {
            return 4;
        }
        if (i == R.id.digit_5) {
            return 5;
        }
        if (i == R.id.digit_6) {
            return 6;
        }
        if (i == R.id.digit_7) {
            return 7;
        }
        if (i == R.id.digit_8) {
            return 8;
        }
        return i == R.id.digit_9 ? 9 : 10;
    }

    public static int c(char c2) {
        k();
        if (Character.isDigit(c2)) {
            return d(Character.digit(c2, 10));
        }
        if (c2 == '.' || c2 == ',') {
            return R.id.dec_point;
        }
        if (c2 == '-' || c2 == 8722 || c2 == 8315) {
            return R.id.op_sub;
        }
        if (c2 == '+') {
            return R.id.op_add;
        }
        if (c2 == '*' || c2 == 215) {
            return R.id.op_mul;
        }
        if (c2 == '/' || c2 == 247 || c2 == 8260) {
            return R.id.op_div;
        }
        if (c2 == 'e' || c2 == 'E') {
            return R.id.const_e;
        }
        if (c2 == 'p' || c2 == 'P' || c2 == 960) {
            return R.id.const_pi;
        }
        if (c2 == '^') {
            return R.id.op_pow;
        }
        if (c2 == '!') {
            return R.id.op_fact;
        }
        if (c2 == '%') {
            return R.id.op_pct;
        }
        if (c2 == '(') {
            return R.id.lparen;
        }
        if (c2 == ')') {
            return R.id.rparen;
        }
        if (c2 == 8730) {
            return R.id.op_sqrt;
        }
        if (String.valueOf(c2).equals(d)) {
            return R.id.dec_point;
        }
        return -1;
    }

    public static int d(int i) {
        switch (i) {
            case 0:
                return R.id.digit_0;
            case 1:
                return R.id.digit_1;
            case 2:
                return R.id.digit_2;
            case 3:
                return R.id.digit_3;
            case 4:
                return R.id.digit_4;
            case 5:
                return R.id.digit_5;
            case 6:
                return R.id.digit_6;
            case 7:
                return R.id.digit_7;
            case 8:
                return R.id.digit_8;
            case 9:
                return R.id.digit_9;
            default:
                return -1;
        }
    }

    public static String e() {
        return String.valueOf(p().getDecimalSeparator());
    }

    public static String f(Context context) {
        String e2 = e();
        int hashCode = e2.hashCode();
        if (hashCode != 44) {
            if (hashCode == 46 && e2.equals(".")) {
                return context.getString(R.string.desc_point);
            }
        } else if (e2.equals(",")) {
            return context.getString(R.string.desc_comma);
        }
        throw new IllegalStateException("Locale " + String.valueOf(Locale.getDefault()) + " returned unknown Latin decimal separator \"" + e2 + "\"!");
    }

    public static String g() {
        return String.valueOf(p().getGroupingSeparator());
    }

    public static String h(Context context, int i) {
        return i(context.getResources(), i);
    }

    public static String i(Resources resources, int i) {
        if (i == R.id.const_pi) {
            return resources.getString(R.string.const_pi);
        }
        if (i == R.id.const_e) {
            return resources.getString(R.string.const_e);
        }
        if (i == R.id.op_sqrt) {
            return resources.getString(R.string.op_sqrt);
        }
        if (i == R.id.op_fact) {
            return resources.getString(R.string.op_fact);
        }
        if (i == R.id.op_pct) {
            return resources.getString(R.string.op_pct);
        }
        if (i == R.id.fun_sin) {
            return String.valueOf(resources.getString(R.string.fun_sin)).concat(String.valueOf(resources.getString(R.string.lparen)));
        }
        if (i == R.id.fun_cos) {
            return String.valueOf(resources.getString(R.string.fun_cos)).concat(String.valueOf(resources.getString(R.string.lparen)));
        }
        if (i == R.id.fun_tan) {
            return String.valueOf(resources.getString(R.string.fun_tan)).concat(String.valueOf(resources.getString(R.string.lparen)));
        }
        if (i == R.id.fun_arcsin) {
            return String.valueOf(resources.getString(R.string.fun_arcsin)).concat(String.valueOf(resources.getString(R.string.lparen)));
        }
        if (i == R.id.fun_arccos) {
            return String.valueOf(resources.getString(R.string.fun_arccos)).concat(String.valueOf(resources.getString(R.string.lparen)));
        }
        if (i == R.id.fun_arctan) {
            return String.valueOf(resources.getString(R.string.fun_arctan)).concat(String.valueOf(resources.getString(R.string.lparen)));
        }
        if (i == R.id.fun_ln) {
            return String.valueOf(resources.getString(R.string.fun_ln)).concat(String.valueOf(resources.getString(R.string.lparen)));
        }
        if (i == R.id.fun_log) {
            return String.valueOf(resources.getString(R.string.fun_log)).concat(String.valueOf(resources.getString(R.string.lparen)));
        }
        if (i == R.id.fun_exp) {
            return String.valueOf(resources.getString(R.string.exponential)).concat(String.valueOf(resources.getString(R.string.lparen)));
        }
        return i == R.id.lparen ? resources.getString(R.string.lparen) : i == R.id.rparen ? resources.getString(R.string.rparen) : i == R.id.op_pow ? resources.getString(R.string.op_pow) : i == R.id.op_mul ? resources.getString(R.string.op_mul) : i == R.id.op_div ? resources.getString(R.string.op_div) : i == R.id.op_add ? resources.getString(R.string.op_add) : i == R.id.op_sub ? resources.getString(R.string.op_sub) : i == R.id.op_sqr ? resources.getString(R.string.squared) : i == R.id.dec_point ? e() : i == R.id.digit_0 ? resources.getString(R.string.digit_0) : i == R.id.digit_1 ? resources.getString(R.string.digit_1) : i == R.id.digit_2 ? resources.getString(R.string.digit_2) : i == R.id.digit_3 ? resources.getString(R.string.digit_3) : i == R.id.digit_4 ? resources.getString(R.string.digit_4) : i == R.id.digit_5 ? resources.getString(R.string.digit_5) : i == R.id.digit_6 ? resources.getString(R.string.digit_6) : i == R.id.digit_7 ? resources.getString(R.string.digit_7) : i == R.id.digit_8 ? resources.getString(R.string.digit_8) : i == R.id.digit_9 ? resources.getString(R.string.digit_9) : "";
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0037  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x002f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static String j(String str) {
        char c2;
        String str2;
        StringBuilder sb = new StringBuilder();
        int length = str.length();
        k();
        for (int i = 0; i < length; i++) {
            char charAt = str.charAt(i);
            if (i == length - 1) {
                c2 = 'e';
                if (charAt == 'e') {
                    str2 = "e";
                    if (str2 != null) {
                        sb.append(String.valueOf(c2));
                    } else {
                        sb.append(str2);
                    }
                }
            }
            c2 = charAt;
            str2 = (String) e.get(Character.valueOf(charAt));
            if (str2 != null) {
            }
        }
        return sb.toString();
    }

    public static void k() {
        Locale locale = Locale.getDefault();
        if (locale.equals(f)) {
            return;
        }
        Resources resources = c.getResources();
        locale.toLanguageTag();
        HashMap hashMap = new HashMap();
        a = hashMap;
        Integer valueOf = Integer.valueOf(R.id.fun_sin);
        hashMap.put("sin", valueOf);
        HashMap hashMap2 = a;
        Integer valueOf2 = Integer.valueOf(R.id.fun_cos);
        hashMap2.put("cos", valueOf2);
        HashMap hashMap3 = a;
        Integer valueOf3 = Integer.valueOf(R.id.fun_tan);
        hashMap3.put("tan", valueOf3);
        HashMap hashMap4 = a;
        Integer valueOf4 = Integer.valueOf(R.id.fun_arcsin);
        hashMap4.put("arcsin", valueOf4);
        HashMap hashMap5 = a;
        Integer valueOf5 = Integer.valueOf(R.id.fun_arccos);
        hashMap5.put("arccos", valueOf5);
        HashMap hashMap6 = a;
        Integer valueOf6 = Integer.valueOf(R.id.fun_arctan);
        hashMap6.put("arctan", valueOf6);
        a.put("asin", valueOf4);
        a.put("acos", valueOf5);
        a.put("atan", valueOf6);
        HashMap hashMap7 = a;
        Integer valueOf7 = Integer.valueOf(R.id.fun_ln);
        hashMap7.put("ln", valueOf7);
        HashMap hashMap8 = a;
        Integer valueOf8 = Integer.valueOf(R.id.fun_log);
        hashMap8.put("log", valueOf8);
        a.put("sqrt", Integer.valueOf(R.id.op_sqrt));
        a.put(resources.getString(R.string.fun_sin), valueOf);
        a.put(resources.getString(R.string.fun_cos), valueOf2);
        a.put(resources.getString(R.string.fun_tan), valueOf3);
        a.put(resources.getString(R.string.fun_arcsin), valueOf4);
        a.put(resources.getString(R.string.fun_arccos), valueOf5);
        a.put(resources.getString(R.string.fun_arctan), valueOf6);
        a.put(resources.getString(R.string.fun_ln), valueOf7);
        a.put(resources.getString(R.string.fun_log), valueOf8);
        for (String str : a.keySet()) {
            b = (1 << str.length()) | b;
        }
        d = e();
        HashMap hashMap9 = new HashMap();
        e = hashMap9;
        hashMap9.put('e', "E");
        e.put('E', "E");
        e.put(' ', " ");
        e.put((char) 8230, "…");
        e.put('/', "/");
        e.put('(', "(");
        e.put(')', ")");
        e.put('l', "l");
        e.put('n', "n");
        e.put(',', g());
        e.put((char) 8730, "√");
        e.put((char) 960, "π");
        e.put('-', "−");
        e.put('.', String.valueOf(d));
        for (int i = 0; i <= 9; i++) {
            e.put(Character.valueOf((char) (i + 48)), i(resources, d(i)));
        }
        f = locale;
    }

    public static boolean l(int i) {
        return i == R.id.op_pow || i == R.id.op_mul || i == R.id.op_div || i == R.id.op_add || i == R.id.op_sub;
    }

    public static boolean m(int i) {
        return i == R.id.fun_arcsin || i == R.id.fun_arccos || i == R.id.fun_arctan;
    }

    public static boolean n(int i) {
        return i == R.id.op_fact || i == R.id.op_pct || i == R.id.op_sqr;
    }

    public static boolean o(int i) {
        return i == R.id.fun_sin || i == R.id.fun_cos || i == R.id.fun_tan;
    }

    private static DecimalFormatSymbols p() {
        return DecimalFormatSymbols.getInstance(new Locale.Builder().setLocale(Locale.getDefault()).setUnicodeLocaleKeyword("nu", "latn").build());
    }
}
