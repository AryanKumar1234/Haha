package defpackage;

import java.util.logging.Logger;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class clj {
    static final Logger a = Logger.getLogger(clj.class.getName());

    private clj() {
    }
}
