package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class bhx {
    public static /* synthetic */ String a(int i) {
        return i != 1 ? i != 2 ? i != 3 ? "null" : "EXPLICITLY_ENABLED" : "EXPLICITLY_DISABLED" : "DEFAULT";
    }
}
