package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class akg {
    public static final akg a = new akg("");
    public final String b;

    public akg(String str) {
        str.getClass();
        this.b = str;
    }
}
