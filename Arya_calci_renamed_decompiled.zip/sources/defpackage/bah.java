package defpackage;

import android.content.ContentResolver;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface bah {
    String a(ContentResolver contentResolver, String str);
}
