package defpackage;

import android.app.usage.StorageStatsManager;
import android.view.autofill.AutofillManager;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class a$$ExternalSyntheticApiModelOutline5 {
    public static /* bridge */ /* synthetic */ Class m$1() {
        return AutofillManager.class;
    }

    public static /* bridge */ /* synthetic */ StorageStatsManager m(Object obj) {
        return (StorageStatsManager) obj;
    }

    /* renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ AutofillManager m23m(Object obj) {
        return (AutofillManager) obj;
    }

    /* renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ Class m25m() {
        return StorageStatsManager.class;
    }
}
