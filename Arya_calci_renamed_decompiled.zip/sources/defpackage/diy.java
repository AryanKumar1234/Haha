package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class diy {
    public static final boolean a = Boolean.parseBoolean(System.getProperty("kotlinx.coroutines.google.stacktrace.recovery", "false"));
}
