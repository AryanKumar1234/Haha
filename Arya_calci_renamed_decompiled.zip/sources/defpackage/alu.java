package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class alu extends ArithmeticException {
    public alu() {
        super("0^0");
    }
}
