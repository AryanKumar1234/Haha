package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
interface tl {
    boolean a(long j);
}
