package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface ddj extends daq {
}
