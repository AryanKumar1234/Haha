package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class bgx {
    public static final bgx a = new bgx();
}
