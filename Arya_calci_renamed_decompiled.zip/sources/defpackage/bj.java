package defpackage;

import android.util.AndroidRuntimeException;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class bj extends AndroidRuntimeException {
    public bj(String str) {
        super(str);
    }
}
