package defpackage;

import java.util.List;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface crr extends List {
    List a();

    void b();

    Object c();
}
