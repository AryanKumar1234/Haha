package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class bmb {
    public abstract void a();
}
