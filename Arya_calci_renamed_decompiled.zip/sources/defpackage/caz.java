package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class caz extends IllegalStateException {
    public caz(String str) {
        super(str);
    }
}
