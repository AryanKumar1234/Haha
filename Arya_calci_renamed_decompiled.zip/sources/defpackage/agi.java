package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public class agi extends bb {
}
