package defpackage;

import android.os.Handler;
import android.os.Looper;

/* compiled from: PG */
/* loaded from: classes2.dex */
public class axk extends Handler {
    public axk(Looper looper) {
        super(looper);
        Looper.getMainLooper();
    }

    public axk(Looper looper, Handler.Callback callback) {
        super(looper, callback);
        Looper.getMainLooper();
    }
}
