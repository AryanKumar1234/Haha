package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class bbr extends Exception {
    public final String a;

    public bbr(String str) {
        this.a = str;
    }
}
