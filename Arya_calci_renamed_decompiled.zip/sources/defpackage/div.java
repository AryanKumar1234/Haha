package defpackage;

import java.util.List;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class div extends diw {
    public final List a;

    public div(List list) {
        super((StackTraceElement[]) list.toArray(new StackTraceElement[0]));
        this.a = list;
    }
}
