package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface ddz extends daq {
}
