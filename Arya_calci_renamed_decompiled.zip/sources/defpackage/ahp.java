package defpackage;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class ahp implements Application.ActivityLifecycleCallbacks {
    private final ahz a;
    private int b;
    private final AtomicBoolean c;

    public ahp(ahz ahzVar) {
        ahzVar.getClass();
        this.a = ahzVar;
        this.c = new AtomicBoolean(false);
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityCreated(Activity activity, Bundle bundle) {
        activity.getClass();
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityDestroyed(Activity activity) {
        activity.getClass();
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityPaused(Activity activity) {
        activity.getClass();
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityResumed(Activity activity) {
        activity.getClass();
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        activity.getClass();
        bundle.getClass();
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityStarted(Activity activity) {
        activity.getClass();
        int i = this.b + 1;
        this.b = i;
        if (i <= 0 || !this.c.compareAndSet(false, true)) {
            return;
        }
        this.a.p(3);
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityStopped(Activity activity) {
        activity.getClass();
        int i = this.b - 1;
        this.b = i;
        if (i == 0 && this.c.compareAndSet(true, false)) {
            this.a.p(4);
        }
    }
}
