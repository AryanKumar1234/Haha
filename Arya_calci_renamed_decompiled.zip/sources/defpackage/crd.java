package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface crd {
    int a();
}
