package defpackage;

import java.util.concurrent.Callable;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final /* synthetic */ class bse implements Callable {
    private final /* synthetic */ int a;

    @Override // java.util.concurrent.Callable
    public final Object call() {
        return null;
    }
}
