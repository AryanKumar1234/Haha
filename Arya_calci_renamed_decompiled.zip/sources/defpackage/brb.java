package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface brb {
    Object a(Object obj);
}
