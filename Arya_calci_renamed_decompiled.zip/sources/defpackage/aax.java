package defpackage;

import android.view.View;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface aax {
    boolean a(View view);
}
