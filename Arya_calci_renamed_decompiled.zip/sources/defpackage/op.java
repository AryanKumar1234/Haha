package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class op {
    public of a;
    public of b;
    public int c;
    public int d;
    public int e;
    public int f;
    public int g;
    public boolean h;
    public boolean i;
    public int j;
}
