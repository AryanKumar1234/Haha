package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
class ckv implements ckz {
    public void a(byte[] bArr, int i) {
        throw null;
    }

    @Override // defpackage.ckz
    public final void b(byte[] bArr) {
        a(bArr, bArr.length);
    }
}
