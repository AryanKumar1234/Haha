package defpackage;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface avx {
    int a(Context context);

    int b(Context context, boolean z);
}
