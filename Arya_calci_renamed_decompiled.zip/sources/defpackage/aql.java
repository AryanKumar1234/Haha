package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aql {
    public static final aql a = new aql(true);
    public final boolean b;

    public aql(boolean z) {
        this.b = z;
    }

    public static aql a() {
        return new aql(false);
    }

    public static aql b() {
        return new aql(false);
    }
}
