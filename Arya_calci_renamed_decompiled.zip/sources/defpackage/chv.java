package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public enum chv {
    SMALL(10),
    MEDIUM(20),
    LARGE(50),
    FULL(-1),
    NONE(0);

    public final int f;

    chv(int i) {
        this.f = i;
    }
}
