package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class avw extends Exception {
    public avw(String str) {
        super(str);
    }

    public avw(String str, Throwable th) {
        super(str, th);
    }
}
