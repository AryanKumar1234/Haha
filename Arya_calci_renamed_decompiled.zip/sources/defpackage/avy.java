package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class avy {
    public int a = 0;
    public int b = 0;
    public int c = 0;
}
