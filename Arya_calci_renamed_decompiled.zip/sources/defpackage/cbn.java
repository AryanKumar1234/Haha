package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class cbn {
    final int a;
    final int b;
    final int c;

    public cbn(int i, int i2, int i3) {
        this.a = i;
        this.b = i2;
        this.c = i3;
    }
}
