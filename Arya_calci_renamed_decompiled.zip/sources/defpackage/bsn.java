package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class bsn {
    public final boolean a;
    public final int b;
    public final int c;

    public bsn(int i, boolean z) {
        this.b = 2;
        this.c = i;
        this.a = z;
    }

    public bsn(int i, int i2, boolean z) {
        this.b = i;
        this.c = i2;
        this.a = z;
    }

    public bsn(int i) {
        this(i, false);
    }

    public bsn(int i, int i2) {
        this(i, i2, false);
    }
}
