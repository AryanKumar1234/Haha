package defpackage;

import com.google.android.calculator.R;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class aju {
    public static final int[] a = {R.attr.imageScalePercent};
}
