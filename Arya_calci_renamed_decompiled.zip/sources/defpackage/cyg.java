package defpackage;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface cyg {
    boolean a(Context context);
}
