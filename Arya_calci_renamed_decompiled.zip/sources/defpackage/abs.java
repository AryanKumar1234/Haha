package defpackage;

import android.view.animation.Interpolator;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class abs implements Interpolator {
    private final /* synthetic */ int a;

    public abs(int i) {
        this.a = i;
    }

    @Override // android.animation.TimeInterpolator
    public final float getInterpolation(float f) {
        int i = this.a;
        float f2 = f - 1.0f;
        return (f2 * f2 * f2 * f2 * f2) + 1.0f;
    }
}
