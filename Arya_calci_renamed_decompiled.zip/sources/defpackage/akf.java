package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface akf {
    void bK();

    void u(long j);

    void v(long j, int i);

    void w(long j, int i, int i2, int i3, String str);
}
