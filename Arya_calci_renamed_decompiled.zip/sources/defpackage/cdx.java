package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class cdx {
    protected cdx() {
    }

    protected abstract Object f();

    public String toString() {
        return f().toString();
    }
}
