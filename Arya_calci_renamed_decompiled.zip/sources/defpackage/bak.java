package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class bak extends Exception {
    public bak(Throwable th) {
        super("ContentProvider query failed", th);
    }

    public bak(String str) {
        super(str);
    }
}
