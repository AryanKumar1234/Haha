package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface xa {
    void a(Object obj);
}
