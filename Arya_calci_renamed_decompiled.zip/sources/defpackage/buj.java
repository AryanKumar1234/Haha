package defpackage;

import java.io.Closeable;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface buj extends Closeable {
    void a();

    @Override // java.io.Closeable, java.lang.AutoCloseable
    void close();
}
