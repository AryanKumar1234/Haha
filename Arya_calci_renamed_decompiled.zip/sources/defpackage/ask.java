package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class ask {
    public final Object a;
    private final String b;

    public ask(Object obj, String str) {
        this.a = obj;
        this.b = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ask)) {
            return false;
        }
        ask askVar = (ask) obj;
        return this.a == askVar.a && this.b.equals(askVar.b);
    }

    public final int hashCode() {
        return (System.identityHashCode(this.a) * 31) + this.b.hashCode();
    }
}
