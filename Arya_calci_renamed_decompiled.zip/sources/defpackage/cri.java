package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface cri extends crj {
    cri a(int i);
}
