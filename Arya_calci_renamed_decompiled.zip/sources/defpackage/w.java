package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class w extends RuntimeException {
    public w(String str, Exception exc) {
        super(str, exc);
    }
}
