package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface chk {
    void a(String str, Object obj);
}
