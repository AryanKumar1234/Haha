package defpackage;

import android.view.ViewGroup;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class ez extends ViewGroup.MarginLayoutParams {
    public ez() {
        super(-1, -1);
    }
}
