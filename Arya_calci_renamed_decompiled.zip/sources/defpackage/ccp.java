package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface ccp {
    Object a(Object obj);
}
