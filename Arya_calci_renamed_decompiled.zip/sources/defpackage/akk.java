package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class akk extends Exception {
    public akk() {
    }

    public akk(String str) {
        super(str);
    }
}
