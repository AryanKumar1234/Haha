package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class bwk {
    public abstract void a();

    public abstract void b();
}
