package defpackage;

import java.util.Comparator;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface cge extends Iterable {
    Comparator comparator();
}
