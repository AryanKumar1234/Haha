package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class cay extends IllegalStateException {
    public cay(String str) {
        super(str);
    }
}
