package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface ao {
    void a();

    void b();

    void c();

    void d();

    void e();
}
