package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface dcv {
    StackTraceElement d();

    dcv f();
}
