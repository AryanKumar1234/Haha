package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public abstract class uh implements Cloneable {
    boolean b;
    boolean c;
    public float d;
    public Class e;
    public ud f = null;

    @Override // 
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public abstract uh clone();

    public abstract Object c();

    public abstract void d(Object obj);
}
