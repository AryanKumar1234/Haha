package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class dgh extends RuntimeException {
    public dgh(String str, Throwable th) {
        super(str, th);
    }
}
