package defpackage;

import android.content.Context;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class avv implements avx {
    private final int a;

    public avv(int i) {
        this.a = i;
    }

    @Override // defpackage.avx
    public final int a(Context context) {
        return this.a;
    }

    @Override // defpackage.avx
    public final int b(Context context, boolean z) {
        return 0;
    }
}
