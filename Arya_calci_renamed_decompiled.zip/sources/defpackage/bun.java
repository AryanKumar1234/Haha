package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface bun {
    coi a();

    coi b();

    coi c();
}
