package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class alt extends ArithmeticException {
    public alt(String str) {
        super(str);
    }
}
