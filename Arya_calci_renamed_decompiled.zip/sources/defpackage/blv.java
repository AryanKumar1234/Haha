package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
final class blv {
    static final blv a = new blv();
}
