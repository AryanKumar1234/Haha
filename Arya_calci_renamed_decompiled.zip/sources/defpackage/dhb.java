package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public interface dhb {
    void e();
}
