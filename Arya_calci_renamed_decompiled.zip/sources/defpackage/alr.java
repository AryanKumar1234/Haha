package defpackage;

/* compiled from: PG */
/* loaded from: classes2.dex */
public final class alr extends ArithmeticException {
    public alr() {
        super("sqrt(definitely negative)");
    }
}
